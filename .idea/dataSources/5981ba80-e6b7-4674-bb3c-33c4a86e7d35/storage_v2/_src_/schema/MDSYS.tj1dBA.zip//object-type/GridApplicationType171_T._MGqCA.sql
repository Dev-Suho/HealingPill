create TYPE         "GridApplicationType171_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","sourceCrs" NUMBER(20),"Transformation" NUMBER(20),"targetCrs" NUMBER(20))NOT FINAL INSTANTIABLE
/

