create TYPE         "ViewFrame3dType206_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3dType207_T","DefaultStyle" "Style3dType200_T")NOT FINAL INSTANTIABLE
/

