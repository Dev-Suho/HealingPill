create TYPE         "LOD211_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","ThemeLOD" NUMBER,"Generalization" "FeatureReferenceType191_T")FINAL INSTANTIABLE
/

