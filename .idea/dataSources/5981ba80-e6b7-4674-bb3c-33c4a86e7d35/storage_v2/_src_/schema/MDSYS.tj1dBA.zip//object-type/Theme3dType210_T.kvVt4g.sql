create TYPE         "Theme3dType210_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"LOD" "LOD211_T","DefaultStyle" "Style3dType200_T","Tiling" "Tiling212_T","hidden_info" "hidden_info213_T","ExternalRepresentations" "ExternalRepresentations216_T")NOT FINAL INSTANTIABLE
/

