create function SDO_Aggr_Union wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
75 9e
r6JsRRjeDhfQtnfjlyXR9p7SbRowg8eZgcfLCNL+XuefCNC/Wa6WGCjX2Udy67j1vyjAMr90
UjK/gf4ysr0Yw6UyvUp0PB3FHaECojlTJ8A+Fja+QEY5OqhdBu6Xvo8bFkY5EpK+1anOaz9n
CtiIppvGqCo=
/

