create type AggrLRSConcat AUTHID current_user as Object
(
  context mdsys.SDOAggr,
  static function odciaggregateinitialize(sctx OUT AggrLRSConcat) return number,
  member function odciaggregateiterate(self IN OUT AggrLRSConcat,
               			       geom IN mdsys.SDOAggrType) return number,
  member function odciaggregateterminate(self IN AggrLRSConcat,
                                        returnValue OUT mdsys.sdo_geometry,
                                          flags IN number)
                     return number,
  member function odciaggregatemerge(self   IN OUT AggrLRSConcat,
                    		     valueB IN  AggrLRSConcat) return number);
/

