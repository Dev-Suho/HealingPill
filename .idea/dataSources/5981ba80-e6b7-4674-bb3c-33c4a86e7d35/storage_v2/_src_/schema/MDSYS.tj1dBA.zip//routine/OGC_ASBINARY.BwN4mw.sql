create FUNCTION OGC_AsBinary(
  g ST_Geometry)
    RETURN BLOB IS
BEGIN
  RETURN g.GET_WKB();
END OGC_AsBinary;
/

