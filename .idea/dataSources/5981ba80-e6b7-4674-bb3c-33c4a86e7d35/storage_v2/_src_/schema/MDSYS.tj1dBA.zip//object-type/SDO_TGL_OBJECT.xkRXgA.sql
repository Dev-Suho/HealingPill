create type SDO_TGL_OBJECT
as Object (tgl_id number, tg_id number)
/

