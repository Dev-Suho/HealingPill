create FUNCTION OGC_StartPoint(
  c ST_Curve)
    RETURN ST_Point IS
BEGIN
  RETURN c.ST_StartPoint();
END OGC_StartPoint;
/

