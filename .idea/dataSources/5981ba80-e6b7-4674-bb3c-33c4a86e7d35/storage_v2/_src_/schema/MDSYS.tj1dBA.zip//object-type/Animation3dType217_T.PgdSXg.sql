create TYPE         "Animation3dType217_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","closedLoop" RAW(1),"SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3d218_COLL","DefaultStyle" "Style3dType200_T")NOT FINAL INSTANTIABLE
/

