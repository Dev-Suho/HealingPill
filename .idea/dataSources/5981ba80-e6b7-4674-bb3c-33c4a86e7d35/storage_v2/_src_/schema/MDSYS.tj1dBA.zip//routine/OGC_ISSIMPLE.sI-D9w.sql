create FUNCTION OGC_IsSimple(
  g ST_Geometry)
    RETURN Integer DETERMINISTIC IS
BEGIN
  RETURN g.ST_IsSimple();
END OGC_IsSimple;
/

