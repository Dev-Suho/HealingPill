create function SDO_Aggr_Centroid wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b5 aa
z+5VVM8NN7BRQZfS8T5Pqb5Pfk0wg8eZgcfLCNL+XuefCNC/Wa6WGL/c19U+l3JZs7j1vyjA
Mr90UjK/gf4ysr0Yw48Jyh/ORTaAOR77zaaIq9OIj+W9IdWFKhQhhSioH9BL50jE5hFLsE+Y
4eO7ivwf0127KeDXpqYfY8VM
/

