create TYPE         "Vis3DConfigType190_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","DefaultTexture" VARCHAR2(4000 CHAR),"Logos" "LogosType187_T","Icons" "IconsType189_T")NOT FINAL INSTANTIABLE
/

