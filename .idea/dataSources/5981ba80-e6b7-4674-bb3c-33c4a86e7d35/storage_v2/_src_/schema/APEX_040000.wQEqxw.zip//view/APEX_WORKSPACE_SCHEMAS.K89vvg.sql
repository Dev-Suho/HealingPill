create view APEX_WORKSPACE_SCHEMAS as
select
    w.PROVISIONING_COMPANY_ID                           workspace_id,
    w.short_name                                        workspace_name,
    w.FIRST_SCHEMA_PROVISIONED                          first_schema_provisioned,
    s.schema                                            schema,
    (select created
     from   sys.all_users
     where  username = s.schema)                        schema_created,
    (select count(*)
     from wwv_flows
     where security_group_id=w.PROVISIONING_COMPANY_ID
      and s.schema = owner)                             applications
from wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where
     (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID
/

comment on table APEX_WORKSPACE_SCHEMAS is 'Database Schemas mapped to APEX workspaces'
/

comment on column APEX_WORKSPACE_SCHEMAS.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_WORKSPACE_SCHEMAS.WORKSPACE_NAME is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_SCHEMAS.FIRST_SCHEMA_PROVISIONED is 'The associated database schema identified when this workspace was created'
/

comment on column APEX_WORKSPACE_SCHEMAS.SCHEMA is 'Database schema name mapped to workspace'
/

comment on column APEX_WORKSPACE_SCHEMAS.SCHEMA_CREATED is 'Identifies the date that the database schema was created'
/

comment on column APEX_WORKSPACE_SCHEMAS.APPLICATIONS is 'Number of applications within the current workspace and schema'
/

