create procedure htmldb_admin
as
begin
    apex_admin;
end;
/

