create package  wwv_flow_debug_message
as

g_max_log_level         number := 7;

------------------------------------------------------------------
-- enable_debug_messages
--
-- turn on debug messaging at a integer level between 1 and 7
-- level 1 is most important
-- level 7 is least important
-- setting p_level to 3 would log any message at level 1, 2, or 3.

procedure enable_debug_messages (
	p_level in number default 7);



------------------------------------------------------------------
-- disable_debug_messages
--
-- turn off debug messaging

procedure disable_debug_messages;



------------------------------------------------------------------
-- remove_session_messages
--
-- delete from the apex debug message log all data for a given session in your workspace
-- defaults to your current session

procedure remove_session_messages(
   p_session in number default null)
   ;

procedure remove_debug_by_app (
    p_application_id in number)
    ;

procedure remove_debug_by_age (
    p_application_id  in number,
    p_older_than_days in number)
    ;

------------------------------------------------------------------
-- obsolete remove_debug_by_age
--
-- due to misspelt parameter p_older_then_days
-- now calls overloaded remove_debug_by_age with correctly spelt
-- parameter p_older_than_days

procedure remove_debug_by_age (
    p_application_id  in number,
    p_older_then_days in number)
    ;



procedure remove_debug_by_view (
    p_application_id  in number,
    p_view_id        in number)
    ;

------------------------------------------------------------------
-- log_message
--
-- arguments
--    p_message: upto 4000 bytes of message
--    p_enabled: messages will be logged when logging is enabled, setting a value of true will log
--    p_level: identifies the level of the log message, 1 is most important, 7 is least important, integer value
--
-- when to use
--    when you want to emit debug messages from plsql components of apex, or plsql procedures and functions
--
-- examples:
--
-- 1. log a simple message, most important, enabled by default (no need to manually enable debug)
--
-- begin wwv_flow_debug_message.log_message('I am here',true,1); end;
--
-- 2. enable log_messages at level 3, e.g. log message level 1, 2, and 3, but not 4, 5, 6, and 7.
--
-- begin
--     wwv_flow_debug_message.enable_debug_messages(p_level=>3);
--     wwv_flow_debug_message.log_message('I am here',true,1);
-- end;
--
-- note: you only need to call enable_debug_messages once per page view / page accept
--
-- log_long_message is the same as log_message except it will split logging into 4000 character chunks


procedure log_message (
    p_message in varchar2 default null,
    p_enabled in boolean  default false,
    p_level   in number   default 7)
    ;
procedure log_long_message (
    p_message in varchar2 default null,
    p_enabled in boolean  default false,
    p_level   in number   default 7);


	------------------------------------------------------------------
	-- log_page_session_state
	--
	-- arguments
	--    p_page_id: identifies a page within the current applicaiton and workspace context
	--    p_enabled: messages will be logged when logging is enabled, setting a value of true will log
	--    p_level: identifies the level of the log message, 1 is most important, 7 is least important, integer value

procedure log_page_session_state (
    p_page_id in number   default null,
    p_enabled in boolean  default false,
    p_level   in number   default 7)
    ;

end wwv_flow_debug_message;
/

