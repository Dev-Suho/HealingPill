create view APEX_APPL_PLUGIN_FILES as
select a.id                 as plugin_file_id,
       f.workspace,
       f.application_id,
       f.application_name,
       a.plugin_id,
       p.name               as plugin_name,
       a.file_name,
       a.mime_type,
       a.file_charset,
       a.file_content,
       a.created_by,
       a.created_on,
       a.last_updated_by,
       a.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p,
       wwv_flow_plugin_files a
 where p.flow_id   = f.application_id
   and a.plugin_id = p.id
/

comment on table APEX_APPL_PLUGIN_FILES is 'Stores the files like CSS, images, javascript files, ... of a plug-in.'
/

comment on column APEX_APPL_PLUGIN_FILES.PLUGIN_FILE_ID is 'Identifies the primary key of this component'
/

comment on column APEX_APPL_PLUGIN_FILES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPL_PLUGIN_FILES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPL_PLUGIN_FILES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPL_PLUGIN_FILES.PLUGIN_ID is 'Id of the plug-in this plug-in file is part of'
/

comment on column APEX_APPL_PLUGIN_FILES.PLUGIN_NAME is 'Name of the plug-in this plug-in file is part of'
/

comment on column APEX_APPL_PLUGIN_FILES.FILE_NAME is 'Name of the file.'
/

comment on column APEX_APPL_PLUGIN_FILES.MIME_TYPE is 'Mime type of the file.'
/

comment on column APEX_APPL_PLUGIN_FILES.FILE_CHARSET is 'IANA charset used for text files.'
/

comment on column APEX_APPL_PLUGIN_FILES.FILE_CONTENT is 'Blob content of the file.'
/

comment on column APEX_APPL_PLUGIN_FILES.CREATED_BY is 'APEX developer who created the plug-in file'
/

comment on column APEX_APPL_PLUGIN_FILES.CREATED_ON is 'Date of creation'
/

comment on column APEX_APPL_PLUGIN_FILES.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPL_PLUGIN_FILES.LAST_UPDATED_ON is 'Date of last update'
/

