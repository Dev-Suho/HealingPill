create view APEX_TEAM_TODOS as
select
    w.PROVISIONING_COMPANY_ID     workspace_id,
    w.short_name                  workspace_name,
    --
	t.ID                          todo_id,
	t.FRIENDLY_ID                 todo_friendly_id,
	t.ASSIGNED_TO                 assigned_to,
	t.CONTRIBUTOR                 contributor,
	t.TASK_NAME                   todo_name,
	t.DESCRIPTION                 todo_description,
	t.ESTIMATED_EFFORT_IN_HOURS   estimated_effort_in_hours,
	t.TASK_STATUS                 todo_status,
	t.TASK_CATEGORY               todo_category,
	t.TASK_TAGS                   tags,
	--
	t.START_DATE                  start_date,
	t.DATE_COMPLETED              date_completed,
	t.DUE_DATE                    due_date,
	--
	t.APPLICATION_ID              apex_application_id,
	t.PAGE_ID                     apex_application_page_id,
	--t.WEBSHEET_ID,
	t.REF_COMPONENT_TYPE,
	--t.CUSTOMER_DETAILS,
	t.PARENT_TASK_ID              parent_todo_id,
	--t.TASK_GROUP                todo_group,
    --
	t.RELEASE                     release,
	t.EVENT_ID                    milestone_id,
	t.FEATURE_ID                  feature_id,
	t.PRODUCT_VERSION             product_version,
	--
	t.CREATED_BY,
	t.CREATED_ON,
	t.UPDATED_BY,
	t.UPDATED_ON
from
    WWV_FLOW_tasks t,
    wwv_flow_companies w
where
    t.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_TODOS is 'Items that need to get done - i.e. to dos.'
/

comment on column APEX_TEAM_TODOS.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_TODOS.WORKSPACE_NAME is 'Name of the workspace.'
/

comment on column APEX_TEAM_TODOS.TODO_ID is 'Primary key of the to do.'
/

comment on column APEX_TEAM_TODOS.TODO_FRIENDLY_ID is 'More readable id for the to do (unique within workspace only).'
/

comment on column APEX_TEAM_TODOS.ASSIGNED_TO is 'Identifies who the to do is assigned to.'
/

comment on column APEX_TEAM_TODOS.CONTRIBUTOR is 'Identifies who is contributing to the completion of the to do.'
/

comment on column APEX_TEAM_TODOS.TODO_NAME is 'Brief description of the to do.'
/

comment on column APEX_TEAM_TODOS.TODO_DESCRIPTION is 'Detailed description of the to do.'
/

comment on column APEX_TEAM_TODOS.ESTIMATED_EFFORT_IN_HOURS is 'Estimate of hours to complete the to do.'
/

comment on column APEX_TEAM_TODOS.TODO_STATUS is 'Status of the to do.'
/

comment on column APEX_TEAM_TODOS.TODO_CATEGORY is 'Category assigned to the to do.'
/

comment on column APEX_TEAM_TODOS.TAGS is 'Tags associated with this to do.'
/

comment on column APEX_TEAM_TODOS.START_DATE is 'Date that work on the to was begun.'
/

comment on column APEX_TEAM_TODOS.DATE_COMPLETED is 'Date to do was completed.'
/

comment on column APEX_TEAM_TODOS.DUE_DATE is 'Date the to do is scheduled to be completed.'
/

comment on column APEX_TEAM_TODOS.APEX_APPLICATION_ID is 'Associated application.'
/

comment on column APEX_TEAM_TODOS.APEX_APPLICATION_PAGE_ID is 'Relevant page within associated application.'
/

comment on column APEX_TEAM_TODOS.PARENT_TODO_ID is 'ID of parent to do (link to todo_id to view hierarchy).'
/

comment on column APEX_TEAM_TODOS.RELEASE is 'Release associated with this to do.'
/

comment on column APEX_TEAM_TODOS.MILESTONE_ID is 'Milestone associated with this to do.'
/

comment on column APEX_TEAM_TODOS.FEATURE_ID is 'Feature associated with this to do.'
/

comment on column APEX_TEAM_TODOS.PRODUCT_VERSION is 'Product version associated with this to do.'
/

comment on column APEX_TEAM_TODOS.CREATED_BY is 'Developer who created this milestone.'
/

comment on column APEX_TEAM_TODOS.CREATED_ON is 'Date on which this milestone was created.'
/

comment on column APEX_TEAM_TODOS.UPDATED_BY is 'Developer who last updated this milestone.'
/

comment on column APEX_TEAM_TODOS.UPDATED_ON is 'Date on which this milestone was last updated.'
/

