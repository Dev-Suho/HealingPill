create view APEX_APPLICATION_PROCESSES as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    p.PROCESS_SEQUENCE               process_sequence,
    --
    decode(p.PROCESS_POINT,
      'BEFORE_HEADER','On Load: Before Header (page template header)',
      'AFTER_HEADER','On Load: After Header (page template header)',
      'BEFORE_BOX_BODY','On Load: Before Body Region(s)',
      'AFTER_BOX_BODY','On Load: After Body Region(s)',
      'BEFORE_FOOTER','On Load: Before Footer (page template footer)',
      'AFTER_FOOTER','On Load: After Footer (page template footer)',
      'ON_SUBMIT_BEFORE_COMPUTATION','On Submit: After Page Submission - Before Computations and Validations',
      'AFTER_SUBMIT','On Submit: After Page Submission - After Computations and Validations',
      'AFTER_AUTHENTICATION','On New Session: After Authentication',
      'ON_DEMAND','On Demand: Run this application process when requested by a page process',
      p.process_point)               process_point,
    --
    decode(p.PROCESS_TYPE,
      'PLSQL','PL/SQL Anonymous Block',
      p.PROCESS_TYPE)                process_type,
    p.process_type                   process_type_code,
    --
    p.PROCESS_NAME                   process_name,
    p.PROCESS_SQL_CLOB               process,
    p.attribute_01,
    p.attribute_02,
    p.attribute_03,
    p.attribute_04,
    p.attribute_05,
    p.attribute_06,
    p.attribute_07,
    p.attribute_08,
    p.attribute_09,
    p.attribute_10,
    p.PROCESS_ERROR_MESSAGE          error_message,
    --
    nvl((select r
    from apex_standard_conditions
    where d = p.PROCESS_WHEN_TYPE ),
    p.PROCESS_WHEN_TYPE)
                                     condition_type,
    p.PROCESS_WHEN                   condition_expression1,
    p.PROCESS_WHEN2                  condition_expression2,
    --p.PROCESS_WHEN_TYPE2             ,
    --p.ITEM_NAME                      ,
    nvl((select case when p.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(p.REQUIRED_PATCH)),
     p.REQUIRED_PATCH)               build_option,
     --
     decode(substr(p.SECURITY_SCHEME,1,1),'!','Not ')||
     nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(p.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     p.SECURITY_SCHEME)              authorization_scheme,
    p.SECURITY_SCHEME                authorization_scheme_id,
    p.LAST_UPDATED_BY                last_updated_by,
    p.LAST_UPDATED_ON                last_updated_on,
    p.PROCESS_COMMENT                component_comment,
    p.id                             application_process_id,
    --
    p.PROCESS_NAME
    ||' seq='||lpad(p.PROCESS_SEQUENCE,5,'00000')
    ||' '||p.PROCESS_POINT
    ||' '||decode(p.PROCESS_TYPE,'PLSQL','PL/SQL Anonymous Block',p.PROCESS_TYPE)
    ||' txt='||dbms_lob.substr(p.PROCESS_SQL_CLOB,50,1)||dbms_lob.getlength(p.PROCESS_SQL_CLOB)
    ||' m='||substr(p.PROCESS_ERROR_MESSAGE,1,30)||length(p.PROCESS_ERROR_MESSAGE)
    ||' cond='||p.PROCESS_WHEN_TYPE
    ||substr(p.PROCESS_WHEN,1,20)||length(p.PROCESS_WHEN)
    ||substr(p.PROCESS_WHEN2,1,20)||length(p.PROCESS_WHEN2)
    ||' b='||nvl((select name from    wwv_flow_security_schemes where   to_char(id)= abs(p.REQUIRED_PATCH) and flow_id = f.id),p.REQUIRED_PATCH)
    ||' s='||decode(substr(p.SECURITY_SCHEME,1,1),'!','Not ')||
     nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(p.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     p.SECURITY_SCHEME)
    component_signature
from wwv_flow_processing p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.id = p.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PROCESSES is 'Identifies Application Processes which can run for every page, on login or upon demand'
/

comment on column APEX_APPLICATION_PROCESSES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PROCESSES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PROCESSES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS_SEQUENCE is 'Identifies the sequence that processes will be considered for execution within each process point'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS_POINT is 'Identifies the point of execution of this process'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS_TYPE is 'Identifies the type of process this is'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS_TYPE_CODE is 'Internal code of PROCESS_TYPE'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS_NAME is 'Identifies this process'
/

comment on column APEX_APPLICATION_PROCESSES.PROCESS is 'Text of the Application Process'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_01 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_02 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_03 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_04 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_05 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_06 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_07 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_08 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_09 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ATTRIBUTE_10 is 'Dynamic attribute to store additional data'
/

comment on column APEX_APPLICATION_PROCESSES.ERROR_MESSAGE is 'Identifies the error message to be displayed if this processes raises an exception'
/

comment on column APEX_APPLICATION_PROCESSES.CONDITION_TYPE is 'Specifies a condition type from the Application Process that conditionally controls whether this Application Process is performed.'
/

comment on column APEX_APPLICATION_PROCESSES.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PROCESSES.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PROCESSES.BUILD_OPTION is 'Application Process will be available for execution if the Build Option is enabled'
/

comment on column APEX_APPLICATION_PROCESSES.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this process to be executed'
/

comment on column APEX_APPLICATION_PROCESSES.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PROCESSES.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PROCESSES.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PROCESSES.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PROCESSES.APPLICATION_PROCESS_ID is 'Primary key of this Application Process'
/

comment on column APEX_APPLICATION_PROCESSES.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

