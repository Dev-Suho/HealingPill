create package wwv_flow_javascript as

-- current version string for the libaries
c_apex_version constant varchar2(10) := '_4_0';
--
--==============================================================================
-- Adds the script tag to load a javascript library.
-- If a library has already been added, it will not be added a second time.
-- Parameter:
--   p_name:           has to be specified without .js
--   p_directory:      has to have a trailing slash
--   p_version:        version identifier which should be added to the library name (optional)
--   p_skip_extension: if true the extension .js is NOT added (optional)
--==============================================================================
procedure add_library(
    p_name           in varchar2,
    p_directory      in varchar2 default wwv_flow.g_image_prefix||'javascript/',
    p_version        in varchar2 default c_apex_version,
    p_skip_extension in boolean  default false );
--
--==============================================================================
-- Adds a javascript code snippets to the HTML output which is executed at the
-- onload event.
-- If an entry with the same key exits it will be ignored.
-- If p_key is null the snippet will always be added.
--
-- Parameter:
--   p_code: javascript code snippet. eg: $s('P1_TEST', 'abc');
--   p_key:  name of the key. eg: APEX_WIDGET
--==============================================================================
procedure add_onload_code(
    p_code in varchar2,
    p_key  in varchar2 default null);
--
--==============================================================================
-- Adds a code snippet which is included inline into the HTML output
-- eg. You can use this procedure to add new functions or global
--     variable declarations.
-- Note: if you want to execute code, you should use add_onload_code
--
-- If an entry with the same key exits it will be ignored.
-- If p_key is null the snippet will always be added.
--
-- Parameter:
--   p_code: javascript code snippet. eg: $s('P1_TEST', 123);
--   p_key:  identifier for the code snippet. If specified and a code snippet with
--           the same name has already been added the new code snippet will be ignored.
--==============================================================================
procedure add_inline_code(
    p_code in varchar2,
    p_key  in varchar2 default null);
--
--==============================================================================
-- Emits code which has been added to the internal buffer.
--==============================================================================
procedure emit_code(
    p_type in varchar2);
--
--==============================================================================
-- Escapes a text so that it can be used in JavaScript without problems.
-- Replaces \ with \\, / with \/, " with \u0022, ' with \u0027, tab with \t,
-- chr(10) with \n.
--==============================================================================
function escape (
    p_text in varchar2 )
    return varchar2;
--
--==============================================================================
-- Returns the escaped text surrounded by double quotes. eg: "That\'s a test"
-- If p_add_comma is TRUE a trailing comma is added.
--==============================================================================
function add_value (
    p_value     in varchar2,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the number, if p_value is NULL the value null is returned.
-- If p_add_comma is TRUE a trailing comma is added.
--==============================================================================
function add_value (
    p_value     in number,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns a JavaScript boolean (true, false, null)
-- If p_add_comma is TRUE a trailing comma is added.
--==============================================================================
function add_value (
    p_value     in boolean,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the date as a javascript object, if p_value is NULL the value null is returned.
-- If p_add_comma is TRUE a trailing comma is added.
--==============================================================================
function add_value (
    p_value     in date,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the attribute and its escaped text surrounded by double quotes.
-- eg: test:"That\'s a test"
-- If p_omit_null is TRUE and p_value is NULL the function returns nothing.
-- If p_add_comma is TRUE a trailing comma is added when a value is returned.
--==============================================================================
function add_attribute (
    p_name      in varchar2,
    p_value     in varchar2,
    p_omit_null in boolean := true,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the attribute and its number, if p_value is NULL the value null is
-- returned. eg. test:123 or test:null
-- If p_omit_null is TRUE and p_value is NULL the function returns nothing.
-- If p_add_comma is TRUE a trailing comma is added when a value is returned.
--==============================================================================
function add_attribute (
    p_name      in varchar2,
    p_value     in number,
    p_omit_null in boolean := true,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the attribute and a JavaScript boolean (true, false, null)
-- If p_omit_null is TRUE and p_value is NULL the function returns nothing.
-- If p_add_comma is TRUE a trailing comma is added when a value is returned.
--==============================================================================
function add_attribute (
    p_name      in varchar2,
    p_value     in boolean,
    p_omit_null in boolean := true,
    p_add_comma in boolean := true )
    return varchar2;
--
--==============================================================================
-- Returns the attribute and its date, if p_value is NULL the value null is
-- returned. eg. test:new Date(2009,0,1) or test:null
-- If p_omit_null is TRUE and p_value is NULL the function returns nothing.
-- If p_add_comma is TRUE a trailing comma is added when a value is returned.
--==============================================================================
function add_attribute (
    p_name      in varchar2,
    p_value     in date,
    p_omit_null in boolean := true,
    p_add_comma in boolean := true )
    return varchar2;

--
--==============================================================================
-- Returns true or false, depending on whether any entries exist for all, or a
-- defined type.
-- If p_type is null, all types are checked (INLINE and ONLOAD)
-- If p_type is not null, only types of type p_type are checked.
--==============================================================================
function has_code_buffered (
    p_type      in varchar2 default null )
    return boolean;

--==============================================================================
-- *** THE FOLLOWING APIs ARE FOR INTERNAL USE ONLY! ***
--==============================================================================
function standard_javascript
    return varchar2;

--==============================================================================
-- Adds a javascript code snippets into an internal buffer which is emitted by
-- the call to emit_code later in the page rendering.
-- If an entry with this same type and key exits it will be ignored.
-- If p_key is null the snippet will always be added to the buffer.
--
-- Parameter:
--   p_code: javascript code snippet. eg: $s('P1_TEST', 'abc');
--   p_key:  name of the key. eg: APEX_WIDGET
--   p_type: name of the code type. eg: ONLOAD, INLINE, LINK
--==============================================================================
procedure add_code (
    p_code in varchar2,
    p_type in varchar2,
    p_key  in varchar2 default null );

--==============================================================================
-- Saves the buffered JavaScript code in the page/region cache table wwv_flow_page_code_cache.
-- If p_region_id is specified, only the JavaScript code for that region is saved.
--==============================================================================
procedure save_in_cache (
    p_page_cache_id in number,
    p_region_id     in number default null );

end wwv_flow_javascript;
/

