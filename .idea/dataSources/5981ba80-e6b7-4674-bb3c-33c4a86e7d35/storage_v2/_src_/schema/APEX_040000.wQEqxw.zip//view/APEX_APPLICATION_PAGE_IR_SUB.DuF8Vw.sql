create view APEX_APPLICATION_PAGE_IR_SUB as
select
w.short_name          workspace,
f.id                  application_id,
f.name                application_name,
r.page_id             page_id,
r.worksheet_id        interactive_report_id,
n.websheet_id         websheet_id,
r.id                  report_id,
r.name                report_name,
n.id                  notify_id,
n.owner               owner,
n.email_address       email_address,
n.email_subject       email_subject,
n.start_date          start_date,
n.end_date            end_date,
n.end_day             end_day,
n.end_day_unit        end_day_unit,
n.offset_date         offset_date,
decode(n.notify_interval,'D','Daily','W','Weekly','M','Monthly',n.notify_interval)
                      notify_interval,
n.status              ,
n.notify_error        error_message,
n.created_on          ,
n.created_by          ,
n.updated_on          last_updated_on,
n.updated_by          last_updated_by
--
from wwv_flow_worksheet_notify n,
     wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and r.id = n.report_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_IR_SUB is 'Identifies subscriptions scheduled in saved reports for an interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.WEBSHEET_ID is 'ID of the Websheet'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.REPORT_ID is 'ID of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.REPORT_NAME is 'The name of report to send subscription'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.NOTIFY_ID is 'ID of this subscription'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.OWNER is 'The user the subscription is used by'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.EMAIL_ADDRESS is 'The email address to send subscription'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.EMAIL_SUBJECT is 'The email subject to send subscription'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.START_DATE is 'Date the subscription starts'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.END_DATE is 'Date the subscription ends'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.END_DAY is 'Number of day the subscription ends'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.END_DAY_UNIT is 'The day unit subscription ends (Day, Week, Month, Year)'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.OFFSET_DATE is 'Date the next subscription needs to send'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.NOTIFY_INTERVAL is 'The interval between the subscriptions'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.STATUS is 'The subscription status'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.ERROR_MESSAGE is 'The error message if subscription fails'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_SUB.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

