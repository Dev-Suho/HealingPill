create view APEX_WORKSPACE_FILES as
select
    w.PROVISIONING_COMPANY_ID                           workspace_id,
    w.short_name                                        workspace_name,
    files.id                                            file_id,
    files.flow_id                                       application_id,
    f.name                                              application_name,
    nvl(files.title,files.filename)                     file_name,
    files.mime_type                                     mime_type,
    files.doc_size                                      file_size,
    files.created_by                                    created_by,
    (select max(email_address)
    from wwv_flow_fnd_user
    where security_group_id = w.PROVISIONING_COMPANY_ID
    and user_name=files.created_by)                     email,
    files.created_on                                    created_on,
    decode(files.file_type,
      'FLOW_EXPORT','Application Export',
      'IMAGE_EXPORT','Text Image Export',
      'PAGE_EXPORT','Application Page Export',
      'SCRIPT','SQL Script',
      'THEME','User Interface Theme Export',
      'XLIFF','XLIFF Application Translation Export',
      files.file_type)                                  file_type,
    files.blob_content                                  document
from WWV_FLOW_FILE_OBJECTS$ files,
     wwv_flows f,
     wwv_flow_company_schemas s,
     wwv_flow_companies w,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      (s.schema = f.owner or f.owner is null) and
      to_char(deleted_as_of,'MM.DD.YYYY') = '01.01.0001' and
      files.flow_id = f.id(+) and
      files.security_group_id = w.PROVISIONING_COMPANY_ID and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY' or f.name is null)
/

comment on table APEX_WORKSPACE_FILES is 'Identifies uploaded files belonging to the workspace in the modplsql or EPG documents table'
/

comment on column APEX_WORKSPACE_FILES.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

comment on column APEX_WORKSPACE_FILES.WORKSPACE_NAME is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_FILES.FILE_ID is 'Primary key that identifies the file'
/

comment on column APEX_WORKSPACE_FILES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_WORKSPACE_FILES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_WORKSPACE_FILES.FILE_NAME is 'Name of the file stored in a database BLOB'
/

comment on column APEX_WORKSPACE_FILES.MIME_TYPE is 'Mime type of the file used when fetching the file over the web'
/

comment on column APEX_WORKSPACE_FILES.FILE_SIZE is 'Size of the file'
/

comment on column APEX_WORKSPACE_FILES.CREATED_BY is 'Identifies the APEX User Name who created the file'
/

comment on column APEX_WORKSPACE_FILES.EMAIL is 'Email address that corresponds to the APEX user name'
/

comment on column APEX_WORKSPACE_FILES.CREATED_ON is 'Identifies the date the file was loaded into the database BLOB'
/

comment on column APEX_WORKSPACE_FILES.FILE_TYPE is 'Identifies the APEX file type if available'
/

comment on column APEX_WORKSPACE_FILES.DOCUMENT is 'The file'
/

