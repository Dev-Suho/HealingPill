create view APEX_APPLICATIONS as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    f.ALIAS                          alias,
    f.OWNER                          owner,
    (select group_name from wwv_flow_application_groups where id = f.group_id) application_group,
    group_id                         application_group_id,
    f.HOME_LINK                      home_link,
    (select name
     from wwv_flow_templates
     where id = f.DEFAULT_PAGE_TEMPLATE)
                                     page_template,
    (select name
     from wwv_flow_templates
     where id = f.ERROR_TEMPLATE)    error_page_template,
    decode(upper(f.WEBDB_LOGGING),
        'YES','Yes',
        'NO','No',f.WEBDB_LOGGING)   logging,
    f.FLOW_LANGUAGE                  application_primary_language,
    f.FLOW_LANGUAGE_DERIVED_FROM     language_derived_from,
    f.date_format                    date_format,
    f.timestamp_format               timestamp_format,
    f.timestamp_tz_format            timestamp_tz_format,
    f.auto_time_zone                 auto_time_zone,
    f.default_error_display_location default_error_display_location,
    f.FLOW_IMAGE_PREFIX              image_prefix,
    decode(f.AUTHENTICATION,
        'CUSTOM2','Authentication Scheme',
        'COOKIE', 'APEX Authentication',
        f.AUTHENTICATION)            authentication_scheme_type,
    f.LOGIN_URL                      login_url,
    f.LOGOUT_URL                     logout_url,
    decode(substr(f.LOGO_IMAGE,1,5),
       'TEXT:','Text Logo',
       'Image Logo')                 logo_type,
    f.LOGO_IMAGE                     logo,
    f.LOGO_IMAGE_ATTRIBUTES          logo_attributes,
    --f.PUBLIC_URL_PREFIX              public_url_prefix,
    f.PUBLIC_USER                    public_user,
    --f.DBAUTH_URL_PREFIX              db_auth_url_prefix,
    f.PROXY_SERVER                   proxy_server,
    f.media_type                     media_type,
    --
    (select max(ss.name) n
     from wwv_flow_custom_auth_setups ss
     where flow_id = f.id and instr(f.CUSTOM_AUTHENTICATION_PROCESS,to_char(id)) > 0)
                                       authentication_scheme,
    --f.CUSTOM_AUTHENTICATION_PAGE     custom_auth_page,
    --f.CUSTOM_AUTH_LOGIN_URL          custom_auth_login_url,
    f.FLOW_VERSION                     version,
    decode(f.FLOW_STATUS,
        'AVAILABLE','Available',
        'AVAILABLE_W_EDIT_LINK','Available with Edit Links',
        'DEVELOPERS_ONLY','Available to Developers Only',
        'RESTRICTED_ACCESS','Restricted Access',
        'UNAVAILABLE','Unavailable',
        'UNAVAILABLE_PLSQL','Unavailable (Status Shown with PL/SQL)',
        'UNAVAILABLE_URL','Unavailable (Redirect to URL)',
        f.flow_status)               availability_status,
    f.FLOW_UNAVAILABLE_TEXT          unavailable_text,
    f.RESTRICT_TO_USER_LIST          restrict_to_user,
    decode(f.APPLICATION_TAB_SET,
        1,'Allowed',0,'Not Allowed',
        'Allowed')                   debugging,
    decode(f.EXACT_SUBSTITUTIONS_ONLY,
       'N','No','Y','Yes',
       f.EXACT_SUBSTITUTIONS_ONLY)   exact_substitutions,
    decode(f.BUILD_STATUS,
       'RUN_ONLY','Run Only',
       'RUN_AND_BUILD','Run and Develop',
       f.BUILD_STATUS)               build_status,
    decode(f.publish_yn,'Y','Yes','N','No','No') publish,
    f.VPD                            vpd,
    --
    decode(substr(f.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(f.SECURITY_SCHEME,'!')
     and    flow_id = f.id),
     f.SECURITY_SCHEME)              authorization_scheme,
    f.security_scheme                authorization_scheme_id,
    --f.REJOIN_EXISTING_SESSIONS       rejoin_sessions,
    f.LAST_UPDATED_BY                last_updated_by,
    f.LAST_UPDATED_ON                last_updated_on,
    f.THEME_ID                       theme_number,
    f.GLOBAL_NOTIFICATION            global_notification,
    decode(f.PAGE_PROTECTION_ENABLED_Y_N,
      'Y','Enabled',
      'N','Disabled',
      'Disabled')                    Session_State_Protection,
    MAX_SESSION_LENGTH_SEC           Maximum_Session_Life_Seconds,
    ON_MAX_SESSION_TIMEOUT_URL       Session_Lifetime_Exceeded_URL,
    MAX_SESSION_IDLE_SEC             Maximum_Session_Idle_Seconds,
    ON_MAX_IDLE_TIMEOUT_URL          Session_Idle_Time_Exceeded_URL,
    -- sub components
    (select count(*) from wwv_flow_steps where flow_id = f.id)               pages,
    (select count(*) from wwv_flow_tabs where flow_id = f.id)                tabs,
    (select count(*) from wwv_flow_toplevel_tabs where flow_id = f.id)       parent_tabs,
    (select count(*) from wwv_flow_items where flow_id = f.id)               application_items,
    (select count(*) from wwv_flow_processing where flow_id = f.id)          application_processes,
    (select count(*) from wwv_flow_computations where flow_id = f.id)        application_computations,
    (select count(*) from wwv_flow_shortcuts where flow_id = f.id)           shortcuts,
    (select count(*) from wwv_flow_shared_web_services where flow_id = f.id) web_services,
    (select count(*) from wwv_flow_trees where flow_id = f.id)               trees,
    (select count(*) from wwv_flow_patches where flow_id = f.id)             build_options,
    (select count(*) from wwv_flow_menus where flow_id = f.id)               breadcrumbs,
    (select count(*) from wwv_flow_icon_bar where flow_id = f.id)            nav_bar_entries,
    (select count(*) from wwv_flow_lists where flow_id = f.id)               lists,
    (select count(*) from wwv_flow_lists_of_values$ where flow_id = f.id)    lists_of_values,
    (select count(*) from wwv_flow_themes where flow_id = f.id)              themes,
    (select count(*) from wwv_flow_custom_auth_setups where flow_id = f.id)  authentication_schemes,
    (select count(*) from WWV_FLOW_SECURITY_SCHEMES where flow_id = f.id)    authorization_schemes,
    (select count(*) from WWV_FLOW_MESSAGES$ where flow_id = f.id)           translation_messages,
    (select count(*) from wwv_flow_install_scripts where flow_id = f.id)     installation_scripts,
    (select count(*) from WWV_FLOW_STEPS where flow_id = f.id and CACHE_PAGE_YN = 'Y') cached_pages,
    (select count(*) from WWV_FLOW_PAGE_PLUGS where flow_id = f.id and PLUG_CACHING in ('CACHED','CACHED_BY_USER')) cached_regions,
    --
    'a='||f.ALIAS
    ||' o='||f.OWNER
    ||' h='||substr(f.HOME_LINK,1,20)||length(f.home_link)
    ||' t='||(select name
     from wwv_flow_templates
     where id = f.DEFAULT_PAGE_TEMPLATE)
    ||' l='||decode(upper(f.WEBDB_LOGGING),'YES','Yes','NO','No',f.WEBDB_LOGGING)
    ||' l='||f.FLOW_LANGUAGE||' '||f.FLOW_LANGUAGE_DERIVED_FROM
    ||' i='||substr(f.FLOW_IMAGE_PREFIX,1,20)||length(f.FLOW_IMAGE_PREFIX)
    ||' a='||substr(f.AUTHENTICATION,1,20)||length(f.AUTHENTICATION)
    ||' l='||substr(f.LOGIN_URL,1,20)||length(f.LOGIN_URL)
    ||' l='||substr(f.LOGOUT_URL,1,20)||length(f.LOGOUT_URL)
    ||' l='||decode(substr(f.LOGO_IMAGE,1,5),
       'TEXT:','TextLogo',
       'Image Logo')
    ||','||substr(f.LOGO_IMAGE,1,20)||length(f.LOGO_IMAGE)
    ||','||substr(f.LOGO_IMAGE_ATTRIBUTES,1,20)||length(f.LOGO_IMAGE_ATTRIBUTES)
    ||' p='||f.PUBLIC_USER
    ||' p='||substr(f.PROXY_SERVER,1,20)||length(f.PROXY_SERVER)
    ||' v='||f.FLOW_VERSION
    ||' s='||decode(f.FLOW_STATUS,
        'AVAILABLE','Available',
        'AVAILABLE_W_EDIT_LINK','AvailwEL',
        'DEVELOPERS_ONLY','DevOnly',
        'RESTRICTED_ACCESS','Rests',
        'UNAVAILABLE','Unavail',
        'UNAVAILABLE_PLSQL','UnavailPL/SQL)',
        'UNAVAILABLE_URL','UnavailableRedir',
        f.flow_status)
    ||' u='||substr(f.FLOW_UNAVAILABLE_TEXT,1,20)||length(f.FLOW_UNAVAILABLE_TEXT)
    ||' r='||substr(f.RESTRICT_TO_USER_LIST,1,20)||length(f.RESTRICT_TO_USER_LIST)
    ||' d='||decode(f.APPLICATION_TAB_SET,
        1,'Allowed',0,'!Allowed',
        'Allowed')
    ||' s='||decode(f.EXACT_SUBSTITUTIONS_ONLY,
       'N','No','Y','Yes',
       f.EXACT_SUBSTITUTIONS_ONLY)
    ||' s='||decode(f.BUILD_STATUS,
       'RUN_ONLY','Run Only',
       'RUN_AND_BUILD','Run+Dev',
       f.BUILD_STATUS)
    ||' v='||substr(f.VPD,1,20)||length(f.vpd)
    ||' a='||decode(substr(f.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(f.SECURITY_SCHEME,'!')
     and    flow_id = f.id),
     f.SECURITY_SCHEME)
    ||' t='||f.THEME_ID
    ||' gn='||substr(f.GLOBAL_NOTIFICATION,1,20)||length(f.GLOBAL_NOTIFICATION)
    ||' pp='||decode(f.PAGE_PROTECTION_ENABLED_Y_N,'Y','Enabled','N','Disabled','Disabled')
    ||' timeout='||MAX_SESSION_LENGTH_SEC||'.'||ON_MAX_SESSION_TIMEOUT_URL||'.'||MAX_SESSION_IDLE_SEC||'.'||ON_MAX_IDLE_TIMEOUT_URL
    component_signature,
    f.security_group_id workspace_id
from wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.security_group_id = s.SECURITY_GROUP_ID and
      s.schema = f.owner and
      /* keep this not exists */
      not exists (
        select 1 from wwv_flow_language_map m
        where m.translation_flow_id = f.id) and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATIONS is 'Applications defined in the current workspace or database user.'
/

comment on column APEX_APPLICATIONS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATIONS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATIONS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATIONS.ALIAS is 'Assigns an alternate alphanumeric application identifier'
/

comment on column APEX_APPLICATIONS.OWNER is 'Identifies the database schema that this application will parse SQL and PL/SQL statements as'
/

comment on column APEX_APPLICATIONS.APPLICATION_GROUP is 'Identifies the name of the application group this application is associated with'
/

comment on column APEX_APPLICATIONS.APPLICATION_GROUP_ID is 'Identifies the ID of the application group this application is associated with'
/

comment on column APEX_APPLICATIONS.HOME_LINK is 'URL used to navigate to the home page of the application'
/

comment on column APEX_APPLICATIONS.PAGE_TEMPLATE is 'The default page template for displaying pages, may be overridden at the page level'
/

comment on column APEX_APPLICATIONS.ERROR_PAGE_TEMPLATE is 'Display unexpected errors on an error page using this page template.'
/

comment on column APEX_APPLICATIONS.LOGGING is 'Determines whether or not user activity is recorded in the activity log'
/

comment on column APEX_APPLICATIONS.APPLICATION_PRIMARY_LANGUAGE is 'Identifies the language in which an application is developed'
/

comment on column APEX_APPLICATIONS.LANGUAGE_DERIVED_FROM is 'For use when translating an application; specifies how APEX determines or derives the application language'
/

comment on column APEX_APPLICATIONS.DATE_FORMAT is 'Application default date format.  Will set NLS_DATE_FORMAT prior to showing or posting a page'
/

comment on column APEX_APPLICATIONS.TIMESTAMP_FORMAT is 'Application default timestamp format.  Will set NLS_TIMESTAMP_FORMAT prior to showing or posting a page'
/

comment on column APEX_APPLICATIONS.TIMESTAMP_TZ_FORMAT is 'Application default timestamp time zone format.  Will set NLS_TIMESTAMP_TZ_FORMAT prior to showing or posting a page'
/

comment on column APEX_APPLICATIONS.AUTO_TIME_ZONE is 'Automatic time zone.  Will derive the client time zone from the browser and set the database session timezone automatically at the beginning of each APEX session'
/

comment on column APEX_APPLICATIONS.DEFAULT_ERROR_DISPLAY_LOCATION is 'The default error display location identifies where validation error message will display. Messages can be displayed on an error page, or inline with the existing page. Inline validations are displayed in the "notification" area (defined as part of the page template), and/or within the item label.'
/

comment on column APEX_APPLICATIONS.IMAGE_PREFIX is 'Determines the virtual path the Web server uses to point to the images directory distributed with APEX'
/

comment on column APEX_APPLICATIONS.AUTHENTICATION_SCHEME_TYPE is 'Identifies the type of authentication, sheme based or APEX internal based'
/

comment on column APEX_APPLICATIONS.LOGIN_URL is 'When running this application redirect to this URL'
/

comment on column APEX_APPLICATIONS.LOGOUT_URL is 'Used as the LOGOUT_URL substitution string and identifies a URL to redirect to when the user wishes to logout of the application'
/

comment on column APEX_APPLICATIONS.LOGO_TYPE is 'Identifies the logo as text or an image'
/

comment on column APEX_APPLICATIONS.LOGO is 'Used as the LOGO substitution string, declarative name of the application which can be referenced from page templates'
/

comment on column APEX_APPLICATIONS.LOGO_ATTRIBUTES is 'Attributes used to display the logo.  HTML SPAN tag attributes for text logos and HTML IMG tag attributes for logos that are images.'
/

comment on column APEX_APPLICATIONS.PUBLIC_USER is 'If the APP_USER equals this database schema name then the user is considered a public or unauthenticated user.  Based on this declarative IS_PUBLIC_USER conditions are determined.'
/

comment on column APEX_APPLICATIONS.PROXY_SERVER is 'Use this proxy server when a proxy server is needed'
/

comment on column APEX_APPLICATIONS.MEDIA_TYPE is 'Application-level Internet media type, used in the Content-Type HTTP header'
/

comment on column APEX_APPLICATIONS.AUTHENTICATION_SCHEME is 'Identifies the current authentication method used by this application. The purpose of authentication is to determine the application users identity'
/

comment on column APEX_APPLICATIONS.VERSION is 'Includes the application''s version number on a page'
/

comment on column APEX_APPLICATIONS.AVAILABILITY_STATUS is 'Specifies whether or not the application is available or unavailable for use'
/

comment on column APEX_APPLICATIONS.UNAVAILABLE_TEXT is 'This attribute in conjunction with the Availability Status.  Identifies the text to display when the application is not available'
/

comment on column APEX_APPLICATIONS.RESTRICT_TO_USER is 'Use this attribute in conjunction with the Availability Status "Restricted Access". Only the users listed in this attribute can run the application.'
/

comment on column APEX_APPLICATIONS.DEBUGGING is 'Determines whether pages may be display in debug mode.  Debugging is typically on for development and turned off for production.'
/

comment on column APEX_APPLICATIONS.EXACT_SUBSTITUTIONS is 'Determines if text substitutions require a trailing dot.  This values should always be Yes.  Provided for compatibility with preproduction releases.'
/

comment on column APEX_APPLICATIONS.BUILD_STATUS is 'Determines if the application is available for development.  Production applications can be set to "Run Only" which will cause the application to appear in the APEX Application Builder.'
/

comment on column APEX_APPLICATIONS.PUBLISH is 'Display this application in a list of available applications'
/

comment on column APEX_APPLICATIONS.VPD is 'Identifies PL/SQL that is dynamically executed immediately after the user is authenticated and before any application logic is processed.  This attribute can assign security policies to restrict access to database tables and views.'
/

comment on column APEX_APPLICATIONS.AUTHORIZATION_SCHEME is 'Identifies an Authorization Scheme that will be applied to all pages of the application'
/

comment on column APEX_APPLICATIONS.AUTHORIZATION_SCHEME_ID is 'Identifies an Authorization Scheme foreign key'
/

comment on column APEX_APPLICATIONS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATIONS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATIONS.THEME_NUMBER is 'Identifies the applications current user interface theme'
/

comment on column APEX_APPLICATIONS.GLOBAL_NOTIFICATION is 'This text is displayed on every page of the application that uses a page template with the #GLOBAL_NOTIFICATION# substitution string'
/

comment on column APEX_APPLICATIONS.SESSION_STATE_PROTECTION is 'Enabling Session State Protection can prevent hackers from tampering with URLs within your application.  When enabled pages and items can be set to require checksums to validate inputs.'
/

comment on column APEX_APPLICATIONS.MAXIMUM_SESSION_LIFE_SECONDS is 'Maximum lifetime of session in seconds'
/

comment on column APEX_APPLICATIONS.SESSION_LIFETIME_EXCEEDED_URL is 'Go to URL when session lifetime exceeded'
/

comment on column APEX_APPLICATIONS.MAXIMUM_SESSION_IDLE_SECONDS is 'Maximum session idle time in seconds'
/

comment on column APEX_APPLICATIONS.SESSION_IDLE_TIME_EXCEEDED_URL is 'Go to URL when session idle time exceeded'
/

comment on column APEX_APPLICATIONS.PAGES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.TABS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.PARENT_TABS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.APPLICATION_ITEMS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.APPLICATION_PROCESSES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.APPLICATION_COMPUTATIONS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.SHORTCUTS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.WEB_SERVICES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.TREES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.BUILD_OPTIONS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.BREADCRUMBS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.NAV_BAR_ENTRIES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.LISTS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.LISTS_OF_VALUES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.THEMES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.AUTHENTICATION_SCHEMES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.AUTHORIZATION_SCHEMES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.TRANSLATION_MESSAGES is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.INSTALLATION_SCRIPTS is 'Count of subordinate objects'
/

comment on column APEX_APPLICATIONS.CACHED_PAGES is 'Count of pages in this application that are defined as cachable'
/

comment on column APEX_APPLICATIONS.CACHED_REGIONS is 'Count of page regions in this application that are defined as cachable'
/

comment on column APEX_APPLICATIONS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

comment on column APEX_APPLICATIONS.WORKSPACE_ID is 'Primary Key of the Workspace'
/

