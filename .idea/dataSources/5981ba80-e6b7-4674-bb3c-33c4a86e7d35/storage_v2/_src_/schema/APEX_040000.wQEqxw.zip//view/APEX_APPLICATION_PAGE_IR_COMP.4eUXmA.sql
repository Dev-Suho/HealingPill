create view APEX_APPLICATION_PAGE_IR_COMP as
select
w.short_name          workspace,
f.id                  application_id,
f.name                application_name,
r.page_id             page_id,
r.worksheet_id        interactive_report_id,
r.id                  report_id,
r.application_user    application_user,
r.name                report_name,
c.id                  computation_id,
c.db_column_name      computation_column_alias,
c.column_identifier   computation_column_identifier,
c.computation_expr    computation_expression,
c.format_mask         computation_format_mask,
c.column_type         computation_column_type,
c.report_label        computation_report_label,
c.column_label        computation_form_label,
-- audit
--
c.created_on        ,
c.created_by        ,
c.updated_on        last_updated_on,
c.updated_by        last_updated_by
--
from wwv_flow_worksheet_computation c,
     wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and r.id = c.report_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_IR_COMP is 'Identifies computations defined in user-level report settings for an interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.REPORT_ID is 'ID of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.APPLICATION_USER is 'The user these report settings are used by'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.REPORT_NAME is 'The name of these report settings'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_ID is 'ID of this computation'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_COLUMN_ALIAS is 'Database column name or expression to use in SQL query when displaying this computation column'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_COLUMN_IDENTIFIER is 'Computation column identifier to use in finding computation column alias'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_EXPRESSION is 'Computation expression'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_FORMAT_MASK is 'Format mask for this computation'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_COLUMN_TYPE is 'Type of data in this computation'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_REPORT_LABEL is 'Report heading label to use for this computation'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.COMPUTATION_FORM_LABEL is 'Single row view label to use for this computation'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_COMP.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

