create view APEX_DEBUG_MESSAGES as
select page_view_id,
       message_timestamp,
       elap as elapsed_time,
       extract(second from (lead(message_timestamp) over (partition by page_view_id, session_id order by page_view_id, message_timestamp, session_id, flow_id, page_id) - message_timestamp)) +
       extract(minute from (lead(message_timestamp) over (partition by page_view_id, session_id order by page_view_id, message_timestamp, session_id, flow_id, page_id) - message_timestamp)) * 60 as execution_time,
       message,
       flow_id as application_id,
       page_id,
       session_id,
       apex_user,
       message_level,
       security_group_id as workspace_id
  from ( select m.*
           from wwv_flow_debug_messages m,
                wwv_flow_companies w
          where m.security_group_id = w.provisioning_company_id
            and w.provisioning_company_id in (
                    select security_group_id
                      from wwv_flow_company_schemas s,
                           (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
                     where (   s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')
                            or d.sgid = s.security_group_id
                           )
                    )
            and (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
          union all
         select m.*
           from wwv_flow_debug_messages2 m,
                wwv_flow_companies w
          where m.security_group_id = w.provisioning_company_id
            and w.provisioning_company_id in (
                    select security_group_id
                      from wwv_flow_company_schemas s,
                           (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
                     where (   s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')
                            or d.sgid = s.security_group_id
                           )
                    )
            and (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
       )
/

comment on column APEX_DEBUG_MESSAGES.PAGE_VIEW_ID is 'Page View Identifier, which is a unique sequence generated for each page view recorded with debugging'
/

comment on column APEX_DEBUG_MESSAGES.MESSAGE_TIMESTAMP is 'Timestamp in GMT that message was saved'
/

comment on column APEX_DEBUG_MESSAGES.ELAPSED_TIME is 'Elapsed time in seconds from the beginning of the page submission or page view'
/

comment on column APEX_DEBUG_MESSAGES.EXECUTION_TIME is 'Time elapsed between the current and the next debug message'
/

comment on column APEX_DEBUG_MESSAGES.MESSAGE is 'Debug message'
/

comment on column APEX_DEBUG_MESSAGES.APPLICATION_ID is 'Application Identifier, unique over all workspaces'
/

comment on column APEX_DEBUG_MESSAGES.PAGE_ID is 'Page Identifier within the specified application'
/

comment on column APEX_DEBUG_MESSAGES.SESSION_ID is 'APEX Session Identifier'
/

comment on column APEX_DEBUG_MESSAGES.APEX_USER is 'Username of the user authenticated to the APEX application'
/

comment on column APEX_DEBUG_MESSAGES.MESSAGE_LEVEL is 'Level of debug message, ranging from 1 to 7'
/

comment on column APEX_DEBUG_MESSAGES.WORKSPACE_ID is 'Application Express Workspace Identifier, unique over all workspaces'
/

