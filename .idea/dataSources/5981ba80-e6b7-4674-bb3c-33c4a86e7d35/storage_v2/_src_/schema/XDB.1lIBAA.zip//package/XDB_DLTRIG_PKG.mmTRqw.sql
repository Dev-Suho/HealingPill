create package     XDB_DLTRIG_PKG wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
71 a2
Rylw7VB4KnZlAhU1cPrLmBvGrpQwg0xH2p6pfC/pzPbqCPJEUh0m4MnnNdd0OnAJvrVMETgB
ECjqOwU7FyGDSHvynvk8VWqL81AUSiYb1OrlJV3yYOPIoy+V9J9dQbGfHGPVljD0NubCsX5g
StL9E+77PXkcPw==
/

