create TYPE       "SERVLET_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","icon" VARCHAR2(4000 CHAR),"servlet-name" VARCHAR2(4000 CHAR),"servlet-language" "XDB$ENUM_T","display-name" VARCHAR2(4000 CHAR),"description" VARCHAR2(4000 CHAR),"servlet-class" VARCHAR2(4000 CHAR),"jsp-file" VARCHAR2(4000 CHAR),"servlet-schema" VARCHAR2(4000 CHAR),"load-on-startup" VARCHAR2(4000 CHAR),"security-role-ref" "security-role-ref23_COLL")FINAL INSTANTIABLE
/

