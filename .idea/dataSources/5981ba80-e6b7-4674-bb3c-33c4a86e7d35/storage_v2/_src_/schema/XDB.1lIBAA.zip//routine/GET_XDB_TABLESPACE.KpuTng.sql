create FUNCTION     get_xdb_tablespace wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
ed fb
2h/qaunBX7sFx0i5JhjdJGiRqSAwgwFKLcusfC9AkEIY/VlQlMbUa2IHcI8n4jvCKg7bla+i
OSyaxWC2LkhFtZi7+RW3n42oVygLU0+SfJ9zAVNMmIamX/+Cr4fC0WwXynnhacxKO7flYJi3
q/siOuCNYulRuF7MXegtVIyfpUMd+jmM21gkXq/o+yD31swFMJToiiatiYUIPfZ/iDzIYb7s
gqOGkwvF8ePtmbXjlQOeCdHJKIgPAIo=
/

