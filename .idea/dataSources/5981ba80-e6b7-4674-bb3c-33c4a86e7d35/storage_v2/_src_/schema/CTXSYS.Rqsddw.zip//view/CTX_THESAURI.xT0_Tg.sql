create view CTX_THESAURI as
select u.name ths_owner,
       ths_name
  from dr$ths, sys.user$ u
 where ths_owner# = u.user#
/

