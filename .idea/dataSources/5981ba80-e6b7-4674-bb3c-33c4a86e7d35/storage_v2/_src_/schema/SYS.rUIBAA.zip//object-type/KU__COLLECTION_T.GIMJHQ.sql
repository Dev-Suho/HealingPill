create type ku$_collection_t as object
(
  toid          raw(16),                                             /* TOID */
  version       number,                      /* internal type version number */
  coll_toid     raw(16),            /* collection TOID (TABLE, VARRAY, etc.) */
  coll_version  number,         /* collection type's internal version number */
  elem_toid     raw(16),                                   /* element's TOID */
  elem_version  number,          /* element's type's internal version number */
  synobj        number,                              /* obj# of type synonym */
  properties    number,                             /* element's properties: */
  /* 0x4000 =   16384 = is a PONTER element */
  /* 0x8000 =   32768 = is a REF element */
  /* 0x10000 =  65536  = no NULL is stored with each element */
  /* 0x20000 =  131072 = number/float elements stored in min. fixed size */
  /* 0x40000 =  262144 = number/float elements stored in varying size    */
  charsetid     number,                                  /* character set id */
  charsetform   number,                                /* character set form */
  /* 1 = implicit: for CHAR, VARCHAR2, CLOB w/o a specified set */
  /* 2 = nchar: for NCHAR, NCHAR VARYING, NCLOB */
  /* 3 = explicit: for CHAR, etc. with "CHARACTER SET ..." clause */
  /* 4 = flexible: for PL/SQL "flexible" parameters */
  length        number,                  /* fixed character string length or */
                                  /* maximum varying character string length */
  precision     number,       /* fixed- or floating-point numeric precision */
  scale         number,                         /* fixed-point numeric scale */
  upper_bound   number,     /* fixed array size or varying array upper bound */
  spare1        number,                      /* fractional seconds precision */
  spare2        number,                  /* interval leading field precision */
  spare3        number,
  coll_type     ku$_simple_type_t,           /* type info for the collection */
  typemd        ku$_simple_type_t        /* type info for collection element */
)
/

