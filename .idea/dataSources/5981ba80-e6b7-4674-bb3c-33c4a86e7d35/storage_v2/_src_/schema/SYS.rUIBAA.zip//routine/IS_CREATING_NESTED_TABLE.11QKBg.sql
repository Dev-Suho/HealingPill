create function is_creating_nested_table
return boolean is
begin
return dbms_standard.is_creating_nested_table;
end;
/

