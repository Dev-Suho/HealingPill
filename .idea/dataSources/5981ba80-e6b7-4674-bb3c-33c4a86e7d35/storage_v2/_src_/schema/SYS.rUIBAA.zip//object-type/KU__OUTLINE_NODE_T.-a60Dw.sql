create type ku$_outline_node_t as object
(
  name          varchar2(30),                              /* outline name  */
  category      varchar2(30),                           /* outline category */
  node          number,                              /* qbc node identifier */
  parent        number,      /* node id of the parent node for current node */
  node_type     number,                                    /* qbc node type */
  node_textlen  number,         /* length of SQL to which this node applies */
  node_textoff  number       /* offset into the SQL statement to which this
                                                               node applies */
)
/

