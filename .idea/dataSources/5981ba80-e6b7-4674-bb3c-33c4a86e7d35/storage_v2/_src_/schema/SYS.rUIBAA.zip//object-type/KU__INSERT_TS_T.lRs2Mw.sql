create type ku$_insert_ts_t as object
(
  base_obj_num  number,           /* object number of base partitioned table */
  position_num  number,          /* position of tablespace specified by user */
  ts_num        number,                                 /* tablespace number */
  name          varchar2(30)                           /* name of tablespace */
)
/

