create type ku$_full_type_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                     /* object number */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  type_t        ku$_type_t,                                   /* type object */
  type_body_t   ku$_type_body_t                          /* type body object */
)
/

