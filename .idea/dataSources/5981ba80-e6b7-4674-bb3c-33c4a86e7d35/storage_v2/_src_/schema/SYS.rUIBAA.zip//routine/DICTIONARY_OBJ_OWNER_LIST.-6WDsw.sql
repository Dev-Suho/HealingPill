create function dictionary_obj_owner_list
(owner_list out ora_name_list_t)
return binary_integer is
begin
return dbms_standard.dictionary_obj_owner_list(owner_list);
end;
/

