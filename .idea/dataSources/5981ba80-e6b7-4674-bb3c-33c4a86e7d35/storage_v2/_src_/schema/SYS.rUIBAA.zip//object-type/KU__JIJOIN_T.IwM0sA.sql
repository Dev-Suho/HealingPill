create type ku$_jijoin_t as object
(
  obj_num       number,                                          /* object # */
  tab1obj_num   number,                                /* table 1 obj number */
  tab1col_num   number,                /* internal column number for table 1 */
  tab2obj_num   number,                                /* table 2 obj number */
  tab2col_num   number,                /* internal column number for table 2 */
  tab1col       ku$_simple_col_t,                          /* table 1 column */
  tab2col       ku$_simple_col_t,                          /* table 2 column */
  joinop        number,                /* Op code as defined in opndef.h (=) */
  flags         number,                                        /* misc flags */
  tab1inst_num  number,           /* instance of table 1 (for multiple refs) */
  tab2inst_num  number            /* instance of table 2 (for multiple refs) */
)
/

