create TYPE dmclbo wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
f4 ca
kYhIWAMpwA6gpe0BvT/v93frCVowgzJKLZ5qfHSi2sHVId9QJH0UBVFTtAlLQ2dJNQUta7Wd
DYRAV8j9uwBK68aipYeHT8EfS6xT2kICTqbdYhOuO8WNnhPkEoBDwqv0uOhKIPBmUW8digOa
dT6kSKJB7KNn6dVd1wwLzfBWN/E+RXck96yn74C8O1BUBwgjkvtk0njl
/

