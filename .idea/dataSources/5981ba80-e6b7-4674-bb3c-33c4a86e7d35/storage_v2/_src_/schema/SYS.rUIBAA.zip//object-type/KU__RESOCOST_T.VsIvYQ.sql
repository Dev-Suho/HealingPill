create type ku$_resocost_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  cost_list     ku$_resocost_list_t                   /* resource cost info */
)
/

