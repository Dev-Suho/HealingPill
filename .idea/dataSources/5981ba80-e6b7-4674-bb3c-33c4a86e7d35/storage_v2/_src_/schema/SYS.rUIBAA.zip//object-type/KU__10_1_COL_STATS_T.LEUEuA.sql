create type ku$_10_1_col_stats_t as object
(
  tab_obj_num       number,             -- table object number
  p_obj_num         number,             -- partition object number
  colname           VARCHAR2(30),       -- column name
  intcol_num        number,             -- internal column number
  distcnt           number,             -- distinct count
  lowval            raw(32),            -- low value
  hival             raw(32),            -- high value
  density           number,             -- density
  null_cnt          number,             -- null count
  avgcln            number,             -- average column length
  cflags            number,             -- flags
  eav               number,             --
  hist_gram_list    ku$_histgrm_list_t, -- histogram list
  hist_gram_min     ku$_histgrm_t,      -- minimum histogram
  hist_gram_max     ku$_histgrm_t       -- maximum histogram
)
/

