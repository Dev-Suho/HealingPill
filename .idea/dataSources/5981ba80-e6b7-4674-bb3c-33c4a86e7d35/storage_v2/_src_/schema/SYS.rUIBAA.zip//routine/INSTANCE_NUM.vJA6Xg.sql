create function instance_num return binary_integer is
begin
return dbms_standard.instance_num;
end;
/

