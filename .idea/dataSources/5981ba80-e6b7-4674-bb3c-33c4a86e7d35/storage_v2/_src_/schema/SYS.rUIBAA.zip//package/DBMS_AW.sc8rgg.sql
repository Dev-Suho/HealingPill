create PACKAGE dbms_aw AUTHID CURRENT_USER AS

  ---------------------
  --  OVERVIEW
  --
  --  This package is the interface to the Express server routines.
  --    interp     - This function interprets an OLAP DML command and
  --                 returns the output as a character LOB.
  --    execute    - This procedure executes an OLAP DML command and uses
  --                 dbms_output to print the results.
  --
  ---------------------
  --  Visibility
  --   All users
  --
  ---------------------
  --  PROCEDURES

  PROCEDURE initdriver;
  PROCEDURE startup;
  PROCEDURE shutdown(force IN BOOLEAN DEFAULT FALSE);
  PROCEDURE toggleDBCreate;
  FUNCTION  interpclob(cmd_clob IN CLOB) RETURN CLOB;
  FUNCTION  getlog return clob;
  PROCEDURE printlog(log_clob IN CLOB);

  -- Routines which handle output for the user
  PROCEDURE run(cmd IN STRING, silent IN            BOOLEAN DEFAULT FALSE);
  PROCEDURE run(cmd IN CLOB,   silent IN            BOOLEAN DEFAULT FALSE);

  -- Routines which pass data back
  PROCEDURE run(cmd IN STRING, output    OUT        STRING);
  PROCEDURE run(cmd IN STRING, output IN OUT NOCOPY CLOB);
  PROCEDURE run(cmd IN CLOB,   output    OUT        STRING);
  PROCEDURE run(cmd IN CLOB,   output IN OUT NOCOPY CLOB);

  PROCEDURE execute(cmd IN STRING);
  FUNCTION  interp(cmd IN string) RETURN clob;
  PROCEDURE interp_silent(cmd IN STRING);
  PROCEDURE infile(ifilename IN STRING);

  FUNCTION  eval_number(cmd IN STRING) RETURN NUMBER;
  FUNCTION  eval_text(cmd IN STRING) RETURN VARCHAR2;

  FUNCTION  olap_on RETURN BOOLEAN;
  FUNCTION  olap_running RETURN BOOLEAN;
  FUNCTION  olap_active RETURN BOOLEAN;

  PROCEDURE advise_rel(  relname    IN VARCHAR2,
                         valueset   IN VARCHAR2,
                         pct        IN BINARY_INTEGER DEFAULT 20,
                         compressed IN BOOLEAN        DEFAULT FALSE);
  PROCEDURE advise_cube( aggmap     IN VARCHAR2,
                         pct        IN BINARY_INTEGER DEFAULT 20,
                         compressed IN BOOLEAN        DEFAULT FALSE);

  PROCEDURE enable_access_tracking(objname IN VARCHAR2);
  PROCEDURE disable_access_tracking(objname IN VARCHAR2);
  PROCEDURE clean_access_tracking(objname IN VARCHAR2);

  NO_HIER                 CONSTANT BINARY_INTEGER := 0;
  MEASURE                 CONSTANT BINARY_INTEGER := 1;
  HIER_PARENTCHILD        CONSTANT BINARY_INTEGER := 2;
  HIER_LEVELS             CONSTANT BINARY_INTEGER := 3;
  HIER_SNOWFLAKE          CONSTANT BINARY_INTEGER := 4;

  PARTBY_DEFAULT          CONSTANT BINARY_INTEGER := 0;
  PARTBY_NONE             CONSTANT BINARY_INTEGER := 1;
  PARTBY_FORCE            CONSTANT BINARY_INTEGER := 2147483647;

  ADVICE_DEFAULT          CONSTANT BINARY_INTEGER := 0;
  ADVICE_FAST             CONSTANT BINARY_INTEGER := 1;
  ADVICE_FULL             CONSTANT BINARY_INTEGER := 2;
  ADVICE_NOSAMPLE         CONSTANT BINARY_INTEGER := 3;

  PROCEDURE sparsity_advice_table(tblname IN     VARCHAR2 DEFAULT NULL);

  PROCEDURE add_dimension_source(dimname  IN      VARCHAR2,
                                 colname  IN      VARCHAR2,
                                 sources  IN OUT  dbms_aw$_dimension_sources_t,
                                 srcval   IN      VARCHAR2 DEFAULT NULL,
                                 dimtype  IN      NUMBER DEFAULT NO_HIER,
                                 hiercols IN      dbms_aw$_columnlist_t
                                          DEFAULT NULL,
                                 partby   IN      NUMBER
                                          DEFAULT PARTBY_DEFAULT);

  PROCEDURE advise_sparsity(fact       IN      VARCHAR2,
                            cubename   IN      VARCHAR2,
                            dimsources IN      dbms_aw$_dimension_sources_t,
                            advmode    IN      BINARY_INTEGER
                                       DEFAULT ADVICE_DEFAULT,
                            partby     IN      BINARY_INTEGER
                                       DEFAULT PARTBY_DEFAULT,
                            advtable   IN      VARCHAR2 DEFAULT NULL);

  FUNCTION advise_dimensionality(cubename   IN     VARCHAR2,
                                 sparsedfn     OUT VARCHAR2,
                                 sparsename IN     VARCHAR2 DEFAULT NULL,
                                 partnum    IN     NUMBER DEFAULT 1,
                                 advtable   IN     VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2;
  PROCEDURE advise_dimensionality(output        OUT NOCOPY CLOB,
                                  cubename   IN     VARCHAR2,
                                  sparsename IN     VARCHAR2 DEFAULT NULL,
                                  dtype      IN     VARCHAR2 DEFAULT 'NUMBER',
                                  advtable   IN     VARCHAR2 DEFAULT NULL);
  FUNCTION advise_partitioning_dimension(cubename IN VARCHAR2,
                                    dimsources IN dbms_aw$_dimension_sources_t,
                                    advtable   IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2;
  FUNCTION advise_partitioning_level(cubename  IN VARCHAR2,
                                    dimsources IN dbms_aw$_dimension_sources_t,
                                    advtable   IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2;

  PROCEDURE aw_update(name     IN VARCHAR2 DEFAULT NULL);
  PROCEDURE aw_update(schema   IN VARCHAR2,
                      name     IN VARCHAR2);

  PROCEDURE aw_attach(name     IN VARCHAR2,
                      forwrite IN BOOLEAN  DEFAULT FALSE,
                      createaw IN BOOLEAN  DEFAULT FALSE,
                      attargs  IN VARCHAR2 DEFAULT NULL,
                      tbspace  IN VARCHAR2 DEFAULT NULL);
  PROCEDURE aw_attach(schema   IN VARCHAR2,
                      name     IN VARCHAR2,
                      forwrite IN BOOLEAN  DEFAULT FALSE,
                      createaw IN BOOLEAN  DEFAULT FALSE,
                      attargs  IN VARCHAR2 DEFAULT NULL,
                      tbspace  IN VARCHAR2 DEFAULT NULL);

  PROCEDURE aw_detach(name     IN VARCHAR2);

  PROCEDURE aw_detach(schema   IN VARCHAR2,
                      name     IN VARCHAR2);

  PROCEDURE aw_create(name     IN VARCHAR2,
                      tbspace  IN VARCHAR2 DEFAULT NULL,
                      partnum  IN NUMBER   DEFAULT 8);

  PROCEDURE aw_copy(oldname IN VARCHAR2,
                    newname IN VARCHAR2,
                    newtablespace IN VARCHAR2 DEFAULT NULL,
                    partnum IN NUMBER DEFAULT 8);

  PROCEDURE aw_copy(oldschema IN VARCHAR2,
                    oldname IN VARCHAR2,
                    newname IN VARCHAR2,
                    newtablespace IN VARCHAR2 DEFAULT NULL,
                    partnum IN NUMBER DEFAULT 8);

  PROCEDURE aw_create(schema   IN VARCHAR2,
                      name     IN VARCHAR2,
                      tbspace  IN VARCHAR2 DEFAULT NULL);

  PROCEDURE aw_delete(name     IN VARCHAR2);
  PROCEDURE aw_delete(schema   IN VARCHAR2,
                      name     IN VARCHAR2);

  PROCEDURE aw_rename(inname   IN VARCHAR2,
                      outname  IN VARCHAR2);

  FUNCTION  aw_tablespace(schema IN VARCHAR2,
                          name   IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION  aw_tablespace(name   IN VARCHAR2) RETURN VARCHAR2;

  TYPE eif_t         IS TABLE OF BLOB NOT NULL;
  TYPE eif_objlist_t IS TABLE OF VARCHAR2(100);

  -- Enumerated Types for the datadfns param to EIF import
  EIFIMP_DATA        CONSTANT BINARY_INTEGER := 1;
  EIFIMP_DEFINES     CONSTANT BINARY_INTEGER := 2;
  EIFIMP_DFNS        CONSTANT BINARY_INTEGER := EIFIMP_DEFINES;
  EIFIMP_DATADEFINES CONSTANT BINARY_INTEGER := 3;
  EIFIMP_DATADFNS    CONSTANT BINARY_INTEGER := EIFIMP_DATADEFINES;

  AWNAME_IS_NULL EXCEPTION;

  FUNCTION  eif_blob_out(name IN VARCHAR2,
                         objlist IN eif_objlist_t DEFAULT NULL,
                         api IN BOOLEAN DEFAULT TRUE) RETURN BLOB;
  FUNCTION  eif_blob_out(schema IN VARCHAR2, name IN VARCHAR2,
                         objlist IN eif_objlist_t DEFAULT NULL,
                         api IN BOOLEAN DEFAULT TRUE) RETURN BLOB;
  PROCEDURE eif_blob_in(name IN VARCHAR2, implob IN BLOB,
                        datadfns IN BINARY_INTEGER DEFAULT EIFIMP_DATA,
                        objlist  IN eif_objlist_t  DEFAULT NULL,
                        api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_blob_in(schema IN VARCHAR2, name IN VARCHAR2, implob IN BLOB,
                        datadfns IN BINARY_INTEGER DEFAULT EIFIMP_DATA,
                        objlist  IN eif_objlist_t  DEFAULT NULL,
                        api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_out(name IN VARCHAR2, expeif OUT eif_t,
                    objlist IN eif_objlist_t DEFAULT NULL,
                    dfns IN BOOLEAN DEFAULT FALSE,
                    api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_out(schema IN VARCHAR2, name IN VARCHAR2, expeif OUT eif_t,
                    objlist IN eif_objlist_t DEFAULT NULL,
                    dfns IN BOOLEAN DEFAULT FALSE,
                    api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_in(name IN VARCHAR2, impeif IN eif_t,
                   datadfns IN BINARY_INTEGER DEFAULT EIFIMP_DATA,
                   objlist IN eif_objlist_t DEFAULT NULL,
                   api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_in(schema IN VARCHAR2, name IN VARCHAR2, impeif IN eif_t,
                   datadfns IN BINARY_INTEGER DEFAULT EIFIMP_DATA,
                   objlist IN eif_objlist_t DEFAULT NULL,
                   api IN BOOLEAN DEFAULT TRUE);
  PROCEDURE eif_delete(eif IN OUT eif_t);
  FUNCTION  get_obj_protect RETURN BOOLEAN;

  bad_compat_error NUMBER := -20002;
  aw_changed_error NUMBER := -20003;
  awname_null_error NUMBER := -20004;
  has_schema_error NUMBER := -20005;
  bad_snowflake_error NUMBER := -20006;

  PROCEDURE convert (awname IN VARCHAR2);
  PROCEDURE convert (oldname IN VARCHAR2, newname IN VARCHAR2,
                     newtablespace IN VARCHAR2 DEFAULT NULL);

  en_tbs_error NUMBER := -20001;
  PROCEDURE move_awmeta(dest_tbs IN VARCHAR2);

  FUNCTION prop_val(rid IN ROWID) RETURN VARCHAR2;
  FUNCTION olap_type(otype IN NUMBER) RETURN VARCHAR2;
  FUNCTION prop_clob(rid IN ROWID) RETURN CLOB;
  FUNCTION prop_len(rid IN ROWID) RETURN NUMBER;
  PROCEDURE gather_stats;
  -- Internal types, not for user consumption
  TYPE loblineiter_t IS RECORD (
    mylob   CLOB,
    loc     NUMBER,
    clength NUMBER,
    cmax    NUMBER,
    linemax NUMBER);
END dbms_aw;
/

