create type ku$_10_2_strmcol_t as object
(
  obj_num       number,                      /* object number of base object */
  col_num       number,                          /* column number as created */
  intcol_num    number,                            /* internal column number */
  segcol_num    number,                          /* column number in segment */
  /* col_sortkey, base_intcol_num not present on 10g */
  /* base_col_type, base_col_name added for bug fix on 10g */
  base_col_type number, /* base column type: 1 = UDT, 2 = XMLType OR or CSX, */
                        /*                   3 = XMLType as CLOB,  0 = other */
  base_col_name varchar2(30),      /* for any xmltype, name of xmltype column*/
  property      number,                     /* column properties (bit flags) */
                /* 0x0400 =    1024 = nested table columns setid             */
            /* 0x00800000 = 8388608 = string column measured in characters   */
  name          varchar2(30),                              /* name of column */
  attrname      varchar2(4000),/* name of type attr. column: null if != type */
  type_num      number,                               /* data type of column */
  length        number,                         /* length of column in bytes */
  precision_num number,                                         /* precision */
  scale         number,                                             /* scale */
  not_null      number,                               /* 0 = nulls permitted */
                                                 /* > 0 = no NULLs permitted */
  charsetid     number,                              /* NLS character set id */
  charsetform   number,
  charlength    number,            /* maximum number of characters in string */
  lob_property  number,                    /* lob$.property if column is lob */
                                /* 0x0200 = LOB data in little endian format */
  typemd        ku$_10_2_strmcoltype_t
)
/

