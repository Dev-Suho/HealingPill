create type ku$_callout_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_name     varchar2(30),                                   /* user name */
  obj_num       number,                                     /* object number */
  base_obj      ku$_schemaobj_t,                            /* schema object */
  package       varchar2(30),                          /* procedural package */
  pkg_schema    varchar2(30),                              /* package schema */
  level_num     number,                                             /* level */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  -- for dbms_plugts
  ts_name       varchar2(30),                             /* tablespace name */
  incl_const    number,
  incl_trig     number,
  incl_grant    number,
  tts_full_chk  number,
  tts_closure_chk number
)
/

