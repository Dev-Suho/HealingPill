create type ku$_qtrans_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  transformation_id    number,                          /* transformation id */
  schema_name          varchar2(30),                               /* schema */
  transform_name       varchar2(30),                  /* transformation name */
  from_obj             ku$_schemaobj_t,                   /* from obj schema */
  to_obj               ku$_schemaobj_t,                     /* to obj schema */
  attribute_num        number,
  sql_expression       clob
)
/

