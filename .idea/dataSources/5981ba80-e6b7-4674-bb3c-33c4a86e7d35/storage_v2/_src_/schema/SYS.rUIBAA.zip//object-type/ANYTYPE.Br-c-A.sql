create TYPE ANYTYPE                                       
AS OPAQUE VARYING (*)
USING library DBMS_ANYTYPE_LIB
(

  /* NAME
         BeginCreate()
     DESCRIPTION
         Creates a new instance of ANYTYPE which can be used to create a
         transient type Description.
     PARAMETERS
         typecode - Use a constant from DBMS_TYPES package.
                    Typecodes for  user-defined type:
                     can be  DBMS_TYPES.TYPECODE_OBJECT
                             DBMS_TYPES.TYPECODE_VARRAY or
                             DBMS_TYPES.TYPECODE_TABLE
                    Typecodes for builtin types:
                             DBMS_TYPES.TYPECODE_NUMBER etc.
         atype - AnyType for a transient-type.

     EXCEPTIONS
  */
  STATIC PROCEDURE BeginCreate(typecode IN PLS_INTEGER,
                               atype OUT NOCOPY AnyType),

  /*
     NAME
         SetInfo
     DESCRIPTION
          This procedure sets any additional information required for
          constructing a COLLECTION or builtin type.
          NOTE: It is an error to call this function on an ANYTYPE that
                represents a persistent user defined type.
     PARAMETERS
          self     - The transient ANYTYPE that is being constructed.

          prec, scale (OPTIONAL) - REQUIRED IF TYPECODE REPRESENTS A NUMBER.
                                   Give precision and scale. ignored otherwise.

          len (OPTIONAL) - REQUIRED IF TYPECODE REPRESENTS A RAW, CHAR,
                           VARCHAR, VARCHAR2 types. Gives length.

          csid, csfrm (OPTIONAL) -  REQUIRED IF TYPECODE REPRESENTS Types
                                    requiring character info. For eg: CHAR,
                                    VARCHAR, VARCHAR2, CFILE.

          atype (OPTIONAL)     - REQUIRED IF collection element TYPECODE IS
                                 a user-defined type like TYPECODE_OBJECT
                                 etc. It is also required for a built-in type
                                 that needs user-defined type information
                                 such as TYPECODE_REF. This parameter is not
                                 needed otherwise.

          The following parameters are required for Collection types:

          elem_tc (OPTIONAL)   - Must be of the collection element's typecode
                                 (from DBMS_TYPES package).
          elem_count (OPTIONAL) - Pass 0 for elem_count if the self represents
                                  a nested table (TYPECODE_TABLE). Otherwise
                                  pass the collection count if self represents
                                  a VARRAY.
     EXCEPTIONS
          - DBMS_TYPES.invalid_parameters
            Invalid Parameters (typecode, typeinfo)
          - DBMS_TYPES.incorrect_usage
            incorrect usage (cannot call after calling EndCreate()
                             etc.)
  */
  MEMBER PROCEDURE SetInfo(self IN OUT NOCOPY AnyType,
           prec IN PLS_INTEGER, scale IN PLS_INTEGER,
           len IN PLS_INTEGER,
           csid IN PLS_INTEGER, csfrm IN PLS_INTEGER,
           atype IN ANYTYPE DEFAULT NULL,
           elem_tc IN PLS_INTEGER DEFAULT NULL,
           elem_count IN PLS_INTEGER DEFAULT 0),

  /*
     NAME
          AddAttr
     DESCRIPTION
          This procedure Adds an attribute to an AnyType (of typecode
          DBMS_TYPES.TYPECODE_OBJECT)
     PARAMETERS
          self     - The transient ANYTYPE that is being constructed.
                     Must be of Type DBMS_TYPES.TYPECODE_OBJECT.

          aname (OPTIONAL) - Attribute's name. Could be null.

          typecode - Attribute's typecode. Can be builtin or user-defined.
                     typecode (from DBMS_TYPES package).

          prec, scale (OPTIONAL) - REQUIRED IF TYPECODE REPRESENTS A NUMBER.
                                   Give precision and scale. ignored otherwise.

          len (OPTIONAL) - REQUIRED IF TYPECODE REPRESENTS A RAW, CHAR,
                           VARCHAR, VARCHAR2 types. Gives length.

          csid, csfrm (OPTIONAL) -  REQUIRED IF TYPECODE REPRESENTS Types
                                    requiring character info. For eg: CHAR,
                                    VARCHAR, VARCHAR2, CFILE.

          attr_type (OPTIONAL) - AnyType corresponding to a User defined Type.
                                 This parameter is required if the attribute is
                                 a user defined type.
       EXCEPTIONS
          - DBMS_TYPES.invalid_parameters
            Invalid Parameters (typecode, typeinfo)
          - DBMS_TYPES.incorrect_usage
            incorrect usage (cannot call after calling EndCreate()
                             etc.)
  */
  MEMBER PROCEDURE AddAttr(self IN OUT NOCOPY AnyType,
           aname IN VARCHAR2,
           typecode IN PLS_INTEGER,
           prec IN PLS_INTEGER, scale IN PLS_INTEGER,
           len IN PLS_INTEGER,
           csid IN PLS_INTEGER, csfrm IN PLS_INTEGER,
           attr_type IN ANYTYPE DEFAULT NULL),


  /*
     NAME
          EndCreate
     DESCRIPTION
          Ends Creation of a transient AnyType. Other creation functions cannot
          be called after this call.
  */
  MEMBER PROCEDURE EndCreate(self IN OUT NOCOPY AnyType),

  /* NAME
         GetPersistent()
     DESCRIPTION
         Returns an ANYTYPE corresponding to a persistent type created
         earlier using the CREATE TYPE SQL statement.
     PARAMETERS
          schema_name - Schema name of the type.
          type_name - Type name.
          version - Type version.
      EXCEPTIONS
  */
  STATIC FUNCTION GetPersistent(schema_name IN VARCHAR2,
                      type_name IN VARCHAR2,
                      version IN varchar2 DEFAULT NULL) return AnyType,

/* ANYTYPE ACCESSOR FUNCTIONS */

  /*
     NAME
          GetInfo
     DESCRIPTION
          Get the Type Information for the ANYTYPE

     PARAMETERS
          prec, scale  - IF TYPECODE REPRESENTS A NUMBER.
                         Give precision and scale. ignored otherwise.

          len  - IF TYPECODE REPRESENTS A RAW, CHAR,
                 VARCHAR, VARCHAR2 types. Gives length.

          csid, csfrm -  IF TYPECODE REPRESENTS Types
                         requiring character info. For eg: CHAR,
                         VARCHAR, VARCHAR2, CFILE.
          schema_name, type_name, version - Type's schema (if persistent),
                                            typename and version.

          numelems - if self is a VARRAY, this gives the varray count.
                  if self is of TYPECODE_OBJECT, this gives the number of
                  attributes.

     RETURNS
          The typecode of self.

     EXCEPTIONS
          - DBMS_TYPES.invalid_parameters
            Invalid Parameters (position is beyond bounds or
                                the AnyType is not properly Constructed).)
  */
  MEMBER FUNCTION GetInfo (self IN AnyType,
       prec OUT PLS_INTEGER, scale OUT PLS_INTEGER,
       len OUT PLS_INTEGER, csid OUT PLS_INTEGER,
       csfrm OUT PLS_INTEGER,
       schema_name OUT VARCHAR2, type_name OUT VARCHAR2, version OUT varchar2,
       numelems OUT PLS_INTEGER)
                 return PLS_INTEGER,


  /*
     NAME
          GetAttrElemInfo
     DESCRIPTION
          Gets the Type Information for an attribute of the
          type (if it is of TYPECODE_OBJECT)
          Gets the Type Information for a collection's element type if the
          self parameter is of a collection type.
     PARAMETERS
          position  - If self is of TYPECODE_OBJECT, this gives the attribute
                      position (starting at 1). It is ignored otherwise.

          prec, scale  - IF attribute/collection element TYPECODE
                         REPRESENTS A NUMBER. gives precision and scale.
                         ignored otherwise.

          len  - IF attribute/collection element TYPECODE REPRESENTS A RAW,
                 CHAR, VARCHAR, VARCHAR2 types. Gives length.

          csid, csfrm -  IF attribute/collection element TYPECODE REPRESENTS
                         Types requiring character info. For eg: CHAR,
                         VARCHAR, VARCHAR2, CFILE, gives charset id etc.

          attr_elt_type - IF attribute/collection element TYPECODE REPRESENTS
                         a user-defined type, this returns the ANYTYPE
                         corresponding to it. User can subsequently describe
                         the attr_elt_type.
          aname  - Attribute name (if it is an attribute of an object type.
                   NULL otherwise.

     RETURNS
          The typecode of the attribute or collection element.

     EXCEPTIONS
          - DBMS_TYPES.invalid_parameters
            Invalid Parameters (position is beyond bounds or
                                the AnyType is not properly Constructed).)
  */
  MEMBER FUNCTION GetAttrElemInfo (self IN AnyType, pos IN PLS_INTEGER,
       prec OUT PLS_INTEGER, scale OUT PLS_INTEGER,
       len OUT PLS_INTEGER, csid OUT PLS_INTEGER, csfrm OUT PLS_INTEGER,
       attr_elt_type OUT ANYTYPE, aname OUT VARCHAR2) return PLS_INTEGER

);
/

