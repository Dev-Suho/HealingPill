create type ku$_add_snap_t as object
(
  REFGROUP       number,                          /* number of refresh group */
  ref_add_user   varchar2(2000),          /* dbms_refresh.add execute string */
  ref_add_dba    varchar2(2000)          /* dbms_irefresh.add execute string */
)
/

