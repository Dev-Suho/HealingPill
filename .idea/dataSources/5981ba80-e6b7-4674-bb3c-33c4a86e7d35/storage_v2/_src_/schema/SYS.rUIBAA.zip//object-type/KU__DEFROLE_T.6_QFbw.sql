create type ku$_defrole_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_id       number,                                       /* profile id  */
  user_name     varchar2(30),                                   /* user name */
  user_type     number,                                /* 0 = role, 1 = user */
  defrole       number,                                 /* default role type */
  role_list     ku$_defrole_list_t                              /* role list */
)
/

