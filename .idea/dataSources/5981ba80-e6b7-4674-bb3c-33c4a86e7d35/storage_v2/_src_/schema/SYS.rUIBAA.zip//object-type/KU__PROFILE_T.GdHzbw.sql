create type ku$_profile_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  profile_id    number,                                       /* profile id  */
  profile_name  varchar2(30),                                /* profile name */
  pass_func_name varchar2(30),                   /* password verify function */
  profile_list  ku$_profile_list_t                     /* profile attributes */
)
/

