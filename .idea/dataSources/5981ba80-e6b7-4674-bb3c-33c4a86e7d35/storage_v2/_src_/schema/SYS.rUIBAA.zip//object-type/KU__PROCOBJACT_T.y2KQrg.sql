create type ku$_procobjact_t as object
(
  package       varchar2(30),                     /* procedural package name */
  schema       varchar2(30)                               /* package schema */
)
/

