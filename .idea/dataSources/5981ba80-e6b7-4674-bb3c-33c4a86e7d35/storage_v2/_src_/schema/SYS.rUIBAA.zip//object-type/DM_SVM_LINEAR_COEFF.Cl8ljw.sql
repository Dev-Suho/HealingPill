create type dm_svm_linear_coeff as object
  (class                 varchar2(4000)
  ,attribute_set         dm_svm_attribute_set)
/

