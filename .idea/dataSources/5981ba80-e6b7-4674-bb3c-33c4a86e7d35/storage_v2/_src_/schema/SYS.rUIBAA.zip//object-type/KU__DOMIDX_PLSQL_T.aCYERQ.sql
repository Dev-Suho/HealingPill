create type ku$_domidx_plsql_t as object
(
  obj_num       number,                 /* object # */
  plsql         ku$_procobj_lines       /* plsql code */
)
/

