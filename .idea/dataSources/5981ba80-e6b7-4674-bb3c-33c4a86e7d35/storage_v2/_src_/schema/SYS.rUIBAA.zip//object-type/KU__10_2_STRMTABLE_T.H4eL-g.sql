create type ku$_10_2_strmtable_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  vers_dpapi    number,                           /* direct path API version */
  endianness    number,                 /* 1 = big-endian, 2 = little-endian */
  charset       varchar2(64),                            /* db character set */
  ncharset      varchar2(64),                           /* db ncharacter set */
  dbtimezone    varchar2(64),                          /* database time zone */
  fdo           raw(100),               /* platform Format Descriptor Object */
  obj_num       number,                                              /* obj# */
  owner_name    varchar2(30),                                  /* owner name */
  name          varchar2(30),                                 /* object name */
  pname         varchar2(30),                              /* partition name */
  property      number,                                  /* table properties */
  col_list      ku$_10_2_strmcol_list_t                   /* list of columns */
)
/

