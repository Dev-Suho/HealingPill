create type ku$_prepost_table_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,
  base_obj      ku$_schemaobj_t,
  action_str    sys.ku$_taction_list_t
)
/

