create PACKAGE dbms_rule AUTHID CURRENT_USER AS

  PROCEDURE evaluate(
        rule_set_name           IN      varchar2,
        evaluation_context      IN      varchar2,
        event_context           IN      sys.re$nv_list := NULL,
        table_values            IN      sys.re$table_value_list := NULL,
        column_values           IN      sys.re$column_value_list := NULL,
        variable_values         IN      sys.re$variable_value_list := NULL,
        attribute_values        IN      sys.re$attribute_value_list := NULL,
        stop_on_first_hit       IN      boolean := FALSE,
        simple_rules_only       IN      boolean := FALSE,
        true_rules              OUT     sys.re$rule_hit_list,
        maybe_rules             OUT     sys.re$rule_hit_list);

  PROCEDURE evaluate(
        rule_set_name           IN      varchar2,
        evaluation_context      IN      varchar2,
        event_context           IN      sys.re$nv_list := NULL,
        table_values            IN      sys.re$table_value_list := NULL,
        column_values           IN      sys.re$column_value_list := NULL,
        variable_values         IN      sys.re$variable_value_list := NULL,
        attribute_values        IN      sys.re$attribute_value_list := NULL,
        simple_rules_only       IN      boolean := FALSE,
        true_rules_iterator     OUT     binary_integer,
        maybe_rules_iterator    OUT     binary_integer);

  FUNCTION get_next_hit(
        iterator                IN      binary_integer)
  RETURN sys.re$rule_hit;

  PROCEDURE close_iterator(
        iterator                IN      binary_integer);

END dbms_rule;
/

