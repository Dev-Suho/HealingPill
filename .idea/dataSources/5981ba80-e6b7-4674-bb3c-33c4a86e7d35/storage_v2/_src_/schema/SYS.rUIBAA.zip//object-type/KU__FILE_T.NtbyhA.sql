create type ku$_file_t as object
(
  name          varchar2(923),   /* raw fname:limited to 923 bytes (max OID) */
  fname         varchar2(2050),  /* fixed filename with sgl. ' escaped as '' */
  fsize         number,                            /* size of file in blocks */
  resize        number,                          /* resize of file in blocks */
  maxextend     number,                                 /* maximum file size */
  inc           number,                                 /* increment ammount */
  ts_num        number,                                 /* tablespace number */
  is_omf        number                   /* 1 if file is an OMF, 0 otherwise */
)
/

