create type ku$_slog_t as object
(
  snapid          integer,                        /* identifies V8 snapshots */
  snaptime        varchar2(21),                       /* when last refreshed */
  tscn            number                                 /* last refresh scn */
)
/

