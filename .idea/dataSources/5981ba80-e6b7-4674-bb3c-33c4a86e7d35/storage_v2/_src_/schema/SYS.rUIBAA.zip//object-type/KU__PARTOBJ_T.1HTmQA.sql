create type ku$_partobj_t as object
(
  obj_num       number,                 /* obj# of partitioned tab. or index */
  parttype      number,                                 /* partitioning type */
             /* 1 = range, 2 = hash, 3 = system 4 = List, 5 = Ref;           */
             /* If range/list/hash, subparttype may be non-zero to indicate  */
             /* type of composite partitioning method.                       */
             /* see subparttype(spare1) for form of subpartitioning used.    */
  partcnt       number,                              /* number of partitions */
  partkeycols   number,                  /* # of columns in partitioning key */
  flags         number,                                             /* flags */
                                    /* 0x01 = local      index      */
                                    /* 0x02 = prefixed   index      */
                                    /* 0x04 = no-align   index      */
                                    /* 0x08 = domain     index      */
                                    /* 0x10 = compressed index      */
                                    /* 0x20 = table has ref ptn'ed children */
                                    /* 0x40 = table is interval partitioned */
                                    /* 0x80 = System managed domain index   */
                                   /* 0x100 = IOT Top index         */
                                   /* 0x200 = LOB column index      */
                                   /* 0x400 = Tracked Table IOT Top index  */
                                   /* 0x800 = Segment creation deferred */
                                  /* 0x1000 = Segment creation immediate */
                /* from kkpac.h:                                             */
                /* LOCAL_INDEX          0x0001 = local partitioned index     */
                /* PREFIXED_INDEX       0x0002 = prefixed index              */
                /* NOALIGN_INDEX        0x0004 = local system part. index    */
                /*                               (alignment means nothing    */
                /*                                because there are          */
                /*                                no part. columns)          */
                /* DOMAIN_INDEX         0x0008 = local domain index          */
                /* COMPRESSED_INDEX     0x0010 = index partitions            */
                /*                               compressed by default       */
  defts_name    varchar2(30),                     /* default tablespace name */
  defblocksize  number,          /* blocksize in bytes of default TABLESPACE */
  defpctfree    number,                                   /* default PCTFREE */
  defpctused    number,                 /* default PCTUSED (N/A for indexes) */
  defpctthres   number,             /* default PCTTHRESHOLD (N/A for tables) */
  definitrans   number,                                  /* default INITRANS */
  defmaxtrans   number,                                  /* default MAXTRANS */
  definiexts    number,                       /* default INITIAL extent size */
  defextsize    number,                          /* default NEXT extent size */
  defminexts    number,                                /* default MINEXTENTS */
  defmaxexts    number,                                /* default MAXEXTENTS */
  defextpct     number,                               /* default PCTINCREASE */
  deflists      number,                           /* default FREELISTS value */
  defgroups     number,         /* default FREELIST GROUPS (N/A for indexes) */
  deflogging    number,           /* default logging attribute of the object */
  defbufpool    number,                         /* default BUFFER_POOL value */
  spare2        number,                              /* subpartitioning info */
  /* from dpart.bsq:                              */
  /* 5 bytes of spare2 are currently spoken for */
  /* byte 0   : subparttype - non-zero implies Composite partitioning */
  /*            (1 - Range, 2 - Hash, 3 - System, 4 - List); */
  /* byte 1   : subpartkeycols; */
  /* bytes 2-3: defsubpartcnt */
  /* byte 4   : compression attribute of the partition */
  /*            following bit patterns are possible: */
  /*            00000000 : Compression not specified */
  /*            00000001 : Compression enabled for direct load operations */
  /*            00000010 : Compression disabled      */
  /*            00000101 : Compression enabled for all operations */
  /*            00001001 : Archive Compression: level 1 */
  /*            00010001 : Archive Compression: level 2 */
  /*            00011001 : Archive Compression: level 3 */
  /*            00100001 : Archive Compression: level 4 */
  /*            00101001 : Archive Compression: level 5 */
  /*            00110001 : Archive Compression: level 6 */
  /*            00111001 : Archive Compression: level 7 */
  /*            All other bit patterns are incorrect. */
  spare3        number,                                     /* spare column  */
  /* byte 1 of spare3 stores dtydef of interval (either DTYNUM, DTYIYM, or
   *  DTYIDS)
   */
  definclcol    number,                          /* default iot include col# */
  defparameters varchar2(1000),                       /* from indpart_param$ */
  /* interval_str and interval_bival new in 11g                              */
  interval_str varchar2(1000),                   /* string of interval value */
  interval_bival raw(200),              /* binary representation of interval */
  insert_ts_list ku$_insert_ts_list_t,      /* store-in list for interval pt */
  defmaxsize    number                                    /* default MAXSIZE */
)
/

