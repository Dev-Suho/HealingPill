create type ku$_constraint_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  con_num       number,                                 /* constraint number */
  owner_name    varchar2(30),                         /* owner of constraint */
  name          varchar2(30),                          /* name of constraint */
  flags         number,                                             /* flags */
  type_num      number,                                  /* constraint type: */
                            /* 1 = table check, 2 = primary key, 3 = unique, */
                             /* 4 = referential, 5 = view with CHECK OPTION, */
                                                 /* 6 = view READ ONLY check */
               /* 7 - table check constraint associated with column NOT NULL */
                                   /* 8 - hash expressions for hash clusters */
                                         /* 9 - Scoped REF column constraint */
                                    /* 10 - REF column WITH ROWID constraint */
                                  /* 11 - REF/ADT column with NOT NULL const */
                                 /* 12 - Log Groups for supplemental logging */
                                    /* 14 - Primary key supplemental logging */
                                     /* 15 - Unique key supplemental logging */
                                    /* 16 - Foreign key supplemental logging */
                                     /* 17 - All column supplemental logging */
  base_obj_num  number,                                     /* base object # */
  base_obj      ku$_schemaobj_t,            /* base table/view schema object */
  col           ku$_simple_col_t,        /* column info for con 0 constraint */
  con0          ku$_constraint0_t,                       /* con 0 constraint */
  con1          ku$_constraint1_t                        /* con 1 constraint */
)
/

