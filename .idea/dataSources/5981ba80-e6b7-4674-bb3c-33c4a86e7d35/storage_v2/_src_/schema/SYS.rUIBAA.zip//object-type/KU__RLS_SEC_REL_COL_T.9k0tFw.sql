create type ku$_rls_sec_rel_col_t as object
(
  sec_rel_col varchar2(30)
)
/

