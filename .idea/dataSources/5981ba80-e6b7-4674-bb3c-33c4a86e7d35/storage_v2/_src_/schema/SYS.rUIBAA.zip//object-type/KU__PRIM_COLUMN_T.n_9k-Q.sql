create type ku$_prim_column_t as object
(
  obj_num       number,                      /* object number of base object */
  col_num       number,                          /* column number as created */
  intcol_num    number,                            /* internal column number */
  segcol_num    number,                          /* column number in segment */
  property      number,                     /* column properties (bit flags) */
  name          varchar2(30),                              /* name of column */
  type_num      number,                               /* data type of column */
  length        number,                         /* length of column in bytes */
  precision_num number,                                         /* precision */
  scale         number,                                             /* scale */
  not_null      number,                               /* 0 = nulls permitted */
                                                 /* > 0 = no NULLs permitted */
  deflength     number,                   /* default value expr. text length */
  default_val   varchar2(4000),             /* default value expression text */
  parsed_def    sys.xmltype,                    /* parsed default expression */
  binarydefval  varchar2(4000),          /* default replace null with clause */
  charsetid     number,                              /* NLS character set id */
  charsetform   number,
  base_intcol_num number,               /* for consistency with ku$_column_t */
  base_col_type number,                 /* for consistency with ku$_column_t */
  base_col_name varchar2(30),           /* for consistency with ku$_column_t */
  con           ku$_constraint0_t,                    /* not null constraint */
  spare1        number,                      /* fractional seconds precision */
  spare2        number,                  /* interval leading field precision */
  spare3        number,
  spare4        varchar2(1000),          /* NLS settings for this expression */
  spare5        varchar2(1000),
  spare6        varchar2(19)
)
/

