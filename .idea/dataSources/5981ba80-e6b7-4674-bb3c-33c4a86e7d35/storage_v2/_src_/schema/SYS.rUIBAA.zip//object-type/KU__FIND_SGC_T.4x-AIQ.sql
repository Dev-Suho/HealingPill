create type ku$_find_sgc_t as object
(
  obj_num               number,                           /* index obj # */
  num_cols              number,                           /* #cols in index */
  index_owner           varchar2(30),
  index_name            varchar2(30),
  table_owner           varchar2(30),
  table_name            varchar2(30),
  col_list              ku$_sgi_col_list_t
)
/

