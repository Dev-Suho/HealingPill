create type dm_nested_categorical as object
  (attribute_name        varchar2(4000)
  ,value                 varchar2(4000))
/

