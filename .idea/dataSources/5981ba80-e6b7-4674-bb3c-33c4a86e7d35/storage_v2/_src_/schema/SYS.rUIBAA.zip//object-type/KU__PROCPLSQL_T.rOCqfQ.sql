create type ku$_procplsql_t as object
( obj_num          number,                 /* spec/body object number */
  procedure_num    number,                  /* procedure# or position */
  entrypoint_num   number)                 /* entrypoint table entry# */
/

