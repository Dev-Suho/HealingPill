create type dm_nmf_feature as object
  (feature_id            number
  ,mapped_feature_id     varchar2(4000)
  ,attribute_set         dm_nmf_attribute_set)
/

