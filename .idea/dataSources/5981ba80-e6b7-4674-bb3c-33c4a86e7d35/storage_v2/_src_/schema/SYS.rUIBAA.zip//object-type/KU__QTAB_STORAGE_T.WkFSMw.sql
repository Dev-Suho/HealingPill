create type ku$_qtab_storage_t as object
(
  obj_num       number,                         /* queue table object number */
  property      number,
  ts_num        number,
  ts_name       varchar2(30),
  pct_free      number,
  pct_used       number,
  initrans      number,
  maxtrans      number
)
/

