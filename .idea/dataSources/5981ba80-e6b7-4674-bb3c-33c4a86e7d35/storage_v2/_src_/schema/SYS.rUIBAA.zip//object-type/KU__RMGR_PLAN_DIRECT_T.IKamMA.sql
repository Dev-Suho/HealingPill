create type ku$_rmgr_plan_direct_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,
  base_obj      ku$_schemaobj_t,
  group_or_subplan  varchar2(30),    /* Name of the consumer group or sub-plan
                                                                 referred to */
  type          number,                     /* 1: plan , 0: GROUP_OR_SUBPLAN */
  cpu_p1        number,           /* 1st parameter for CPU allocation method */
  cpu_p2        number,           /* 2nd parameter for CPU allocation method */
  cpu_p3        number,           /* 3rd parameter for CPU allocation method */
  cpu_p4        number,           /* 4th parameter for CPU allocation method */
  cpu_p5        number,           /* 5th parameter for CPU allocation method */
  cpu_p6        number,           /* 6th parameter for CPU allocation method */
  cpu_p7        number,           /* 7th parameter for CPU allocation method */
  cpu_p8        number,           /* 8th parameter for CPU allocation method */
  active_sess_pool_p1   number,       /* 1st parameter for max active sessions
                                                    target allocation method */
  queueing_p1           number,     /* 1st parameter for the queueing method */
  parallel_degree_limit_p1 number,   /* 1st parameter for the parallel degree
                                            limit resource allocation method */
  switch_group          varchar2(30),   /* group to switch to once switch time
                                                                  is reached */
  switch_time           number,       /* switch time limit for execution within
                                                                     a group */
  switch_estimate       number,   /* use execution estimate to determine
                                                                      group? */
  max_est_exec_time     number,      /* use of max. estimated execution time */
  undo_pool             number,  /* max. undo allocation for consumer groups */
  comments              varchar(2000), /* Text comment on the plan directive */
  status                varchar2(30),                 /* PENDING  or ACTIVE  */
  mandatory             number                               /* 1 yes, 0 no  */
)
/

