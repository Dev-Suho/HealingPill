create type ku$_m_view_srt_t as object
(
  tablenum          number,           /* order of Master table in snap query */
  snaptime          varchar2(21),          /* time of last refresh for table */
  mowner            varchar2(30),                     /* owner of this table */
  master            varchar2(30),                      /* name of this table */
  masflag           number,                 /* additional master information */
  masobj_num        number,                    /* obj number of master table */
  loadertime        varchar2(21),      /* last refresh w.r.t. SQL*Loader log */
  refscn            number, /* scn of latest info used to refresh this table */
  lastsuccess       varchar2(21),   /* time of last known successful refresh */
  fcmaskvec         raw(255),                  /* filter columns mask vector */
  ejmaskvec         raw(255),               /* equi-join columns mask vector */
  sub_handle        number,            /* subscription handle (if using CDC) */
  change_view       varchar2(30),         /* change view name (if using CDC) */
  scm_count         number,
  scm_list          ku$_m_view_scm_list_t
)
/

