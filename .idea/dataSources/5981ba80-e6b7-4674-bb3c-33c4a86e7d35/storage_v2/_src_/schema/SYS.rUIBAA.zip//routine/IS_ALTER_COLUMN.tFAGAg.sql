create function is_alter_column (column_name varchar2)
return boolean is
begin
return dbms_standard.is_alter_column(column_name);
end;
/

