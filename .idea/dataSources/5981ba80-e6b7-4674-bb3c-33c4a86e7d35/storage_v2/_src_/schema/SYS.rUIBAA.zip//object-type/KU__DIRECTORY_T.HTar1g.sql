create type ku$_directory_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                           /* directory object number */
  schema_obj    ku$_schemaobj_t,                  /* directory schema object */
  audit_val     varchar2(38),                            /* auditing options */
  os_path       varchar2(4000)                             /* OS path string */
)
/

