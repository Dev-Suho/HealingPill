create type ku$_extloc_t as object
(
  obj_num       number,                          /* base table object number */
  position      number,                               /* this location index */
  dir           varchar2(30),                   /* location directory object */
  name          varchar2(4000)                              /* location name */
)
/

