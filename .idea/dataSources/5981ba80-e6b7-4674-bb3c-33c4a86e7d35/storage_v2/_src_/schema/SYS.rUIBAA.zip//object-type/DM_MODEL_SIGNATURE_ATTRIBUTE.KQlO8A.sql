create type dm_model_signature_attribute as object
  (attribute_name        varchar2(30)
  ,attribute_type        varchar2(106))
/

