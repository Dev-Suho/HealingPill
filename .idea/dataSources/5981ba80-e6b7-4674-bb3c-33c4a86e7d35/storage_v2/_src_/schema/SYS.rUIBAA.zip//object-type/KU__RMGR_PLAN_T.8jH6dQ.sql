create type ku$_rmgr_plan_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,
  schema_obj    ku$_schemaobj_t,
  cpu_method    varchar2(30), /* CPU resource allocation method for the plan */
  mast_method   varchar2(30),     /* maximum active sessions target resource */
                                  /* allocation method for the plan          */
  pdl_method    varchar2(30),              /* parallel degree limit resource */
                                           /* allocation method for the plan */
  num_plan_directives   number,    /* Number of plan directives for the plan */
  description   varchar2(2000),                  /* Text comment on the plan */
  que_method    varchar2(30),                  /* queueing method for groups */
  status        varchar2(30),                           /* PENDING or ACTIVE */
  mandatory     number                      /* Whether the plan is mandatory */
)
/

