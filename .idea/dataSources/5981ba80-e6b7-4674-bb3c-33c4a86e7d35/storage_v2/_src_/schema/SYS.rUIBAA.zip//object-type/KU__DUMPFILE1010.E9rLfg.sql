create TYPE     ku$_DumpFile1010 IS OBJECT
        (
                file_name           VARCHAR2(4000),   -- Fully-qualified name
                file_type           NUMBER,           -- 0=Disk, 1=Pipe, etc.
                file_size           NUMBER,           -- Its length in bytes
                file_bytes_written  NUMBER            -- Bytes written so far
        )
/

