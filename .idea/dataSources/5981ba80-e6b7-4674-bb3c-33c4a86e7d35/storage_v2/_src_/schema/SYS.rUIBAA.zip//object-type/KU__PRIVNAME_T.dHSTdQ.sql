create type ku$_privname_t as object
(
  privname      varchar2(40))
/

