create type ku$_fba_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                        /* table obj# */
  fa_num        number,                               /* flashback archive # */
  fa_name       varchar2(255)                      /* flashback archive name */
)
/

