create type dm_cost_element as object (
  actual      varchar2(4000),
  predicted   varchar2(4000),
  cost        number)
/

