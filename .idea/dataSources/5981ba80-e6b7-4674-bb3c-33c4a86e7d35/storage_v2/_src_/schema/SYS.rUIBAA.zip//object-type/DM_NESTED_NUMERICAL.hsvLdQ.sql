create type dm_nested_numerical as object
  (attribute_name        varchar2(4000)
  ,value                 number)
/

