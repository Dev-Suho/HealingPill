create TYPE ku$_ObjNumPair  AS OBJECT (
  num1          NUMBER,
  num2          NUMBER
)
/

