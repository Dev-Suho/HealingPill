create TYPE     ku$_procobj_line AS OBJECT
        (       grantor         VARCHAR2(30),
                locs            sys.ku$_procobj_locs )
/

