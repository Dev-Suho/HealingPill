create TYPE JOB AS OBJECT
(
  -- Job name and classification
  job_name              VARCHAR2(100),
  job_class             VARCHAR2(32),
  job_style             VARCHAR2(11),

  -- Program/template related attributes
  -- Lightweight jobs cannot have inlined program
  job_template          VARCHAR2(100),
  program_action        VARCHAR2(4000),
  action_type           VARCHAR2(20),

  -- Schedule related attributes
  -- Lightweight jobs cannot have start_date, end_date or
  -- schedule_limit set.
  schedule_name         VARCHAR2(65),
  repeat_interval       VARCHAR2(4000),
  schedule_limit        INTERVAL DAY TO SECOND,
  start_date            TIMESTAMP WITH TIME ZONE,
  end_date              TIMESTAMP WITH TIME ZONE,
  event_condition       VARCHAR2(4000),
  queue_spec            VARCHAR2(100),

  -- Argument related attributes
  number_of_args        NUMBER,
  arguments             SYS.JOBARG_ARRAY,

  -- Misc other attributes
  -- Of these only priority, logging_level, restartable and
  -- stop_on_window_exit are settable for lightweight jobs
  priority              NUMBER,
  job_weight            NUMBER,
  max_run_duration      INTERVAL DAY TO SECOND,
  max_runs              NUMBER,
  max_failures          NUMBER,
  logging_level         NUMBER,
  restartable           VARCHAR2(5),
  stop_on_window_exit   VARCHAR2(5),
  raise_events          NUMBER,
  comments              VARCHAR2(240),
  auto_drop             VARCHAR2(5),
  enabled               VARCHAR2(5),
  follow_default_tz     VARCHAR2(5),
  parallel_instances    VARCHAR2(5),
  aq_job                VARCHAR2(5),
  instance_id           NUMBER,
  -- named program and named schedule
  CONSTRUCTOR FUNCTION job
  (
    job_name            IN     VARCHAR2,
    job_style           IN     VARCHAR2 DEFAULT 'REGULAR',
    job_template        IN     VARCHAR2 DEFAULT NULL,
    program_action      IN     VARCHAR2 DEFAULT NULL,
    action_type         IN     VARCHAR2 DEFAULT NULL,
    schedule_name       IN     VARCHAR2 DEFAULT NULL,
    repeat_interval     IN     VARCHAR2 DEFAULT NULL,
    event_condition     IN     VARCHAR2 DEFAULT NULL,
    queue_spec          IN     VARCHAR2 DEFAULT NULL,
    start_date          IN     TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    end_date            IN     TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    number_of_args      IN     NATURAL DEFAULT NULL,
    arguments           IN     SYS.JOBARG_ARRAY DEFAULT NULL,
    job_class           IN     VARCHAR2 DEFAULT 'DEFAULT_JOB_CLASS',
    schedule_limit      IN     INTERVAL DAY TO SECOND DEFAULT NULL,
    priority            IN     NATURAL DEFAULT NULL,
    job_weight          IN     NATURAL DEFAULT NULL,
    max_run_duration    IN     INTERVAL DAY TO SECOND DEFAULT NULL,
    max_runs            IN     NATURAL DEFAULT NULL,
    max_failures        IN     NATURAL DEFAULT NULL,
    logging_level       IN     NATURALN DEFAULT 64,
    restartable         IN     BOOLEAN DEFAULT FALSE,
    stop_on_window_exit IN     BOOLEAN DEFAULT FALSE,
    raise_events        IN     NATURAL DEFAULT NULL,
    comments            IN     VARCHAR2 DEFAULT NULL,
    auto_drop           IN     BOOLEAN DEFAULT TRUE,
    enabled             IN     BOOLEAN DEFAULT FALSE,
    follow_default_tz   IN     BOOLEAN DEFAULT FALSE,
    parallel_instances  IN     BOOLEAN DEFAULT FALSE,
    aq_job              IN     BOOLEAN DEFAULT FALSE,
    instance_id         IN     NATURAL DEFAULT NULL
  )
  RETURN SELF AS RESULT
);
/

