create type ku$_fga_rel_col_t as object
(
    audit_column varchar2(30)
)
/

